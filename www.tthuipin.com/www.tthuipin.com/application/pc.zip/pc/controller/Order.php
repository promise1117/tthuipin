<?php
namespace app\pc\controller;
use app\pc\controller\Base;
use think\Db;
use think\Request;
class Order extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->order = Db('Order');

        //获取header頂部分类名
        $this->catList = $this->getCategoryParentList();
        foreach($this->catList as $k=>$v){
            $cat_two = Db::name('category')->where('parent_id',$v['cat_id'])->where('is_show','1')->order('sort_order','desc')->select();
            $this->catList[$k]['cat_two'] = $cat_two;
        }
        $this->assign('catlist',$this->catList);

        // 購物車
        $this->shop_car = $this->carSession();
        $this->assign('shop_car',$this->shop_car);
    }

    public function pcSureOrder(Request $request)
    {



        if(input("?post.goods_no")){
            $goods_no = input("post.goods_no");

            $res = Db('Goods')->where('goods_no',$goods_no)->find();
            $res['img'] = input('post.img');
            $res['order'] = $request->post();

            $res['order']['num'] = 1;

            $shop_car = session('shop_car')?session('shop_car'):array();


            foreach ($shop_car as $k=>$v){
                if($v['goods_no'] == $res['goods_no']){
                    array_splice($shop_car,$k,1);
                    $this->error('请勿重复提交数据!','pc/Order/pcSureOrder');
                }
            }
            array_push($shop_car,$res);
            // dump(session('shop_car'));die;
            session('shop_car',$shop_car);


            $this->shop_car = session('shop_car');
//            dump($this->shop_car);
        }else{

            $this->shop_car = session('shop_car')??array();

        }


//        $parameter = input();
//        $data = [
//            'order_no' => 'TW'.setNumber(), //订单号
//            ''
//        ];
//        $info = $this->order->add();
//        return $info;

        /**
         * 根據提交的方式,如果是添加購物車方式直接跳到原頁面,否則進入購物車頁面
         */

        if(!input('?type')){
            return $this->fetch('pc_sure_order',[
                'shop_car'=>$this->shop_car,
            ]);
        }else{
            header('location:'.getenv("HTTP_REFERER"));
        }

    }

    public function pcDel(){
        $data_number = input('post.data_number');
        if(session('shop_car')){
            $data = session('shop_car');
            foreach($data as $k=>$v){
                if($data_number == $v['goods_no']) unset($data[$k]);
            }
        }
        session('shop_car',$data);
        return session('shop_car');
    }

    public function pcSureAddress(){
        $parameter = input();

        if(empty($parameter['total_sell_price'])){
            $this->error('您的購物車沒有商品哦，快去逛逛吧！','/');
        }


        if(session('shop_car')){
            foreach(session('shop_car') as $k=>$v){
                $temp = session('shop_car');
                $temp[$k]['order']['num'] = $parameter['num'][$k];
                session('shop_car',$temp);

            }
        }

        return $this->fetch('pc_sure_address',[
            'data'=> $parameter,
            'shop_car'=>session('shop_car')
        ]);
    }
    public function pcSureMoney(){
        $parameter = input();

        if(session('shop_car')){
            foreach(session('shop_car') as $k=>$v){
                $order['order_info'][$k] = $v['order'];
                $order['order_info'][$k]['sell_price'] = $parameter['payable_amount'];
                $user_id = Db::name('goods')->where('goods_no',$v['order']['goods_no'])->find();
                Db('Goods')->where('goods_no',$v['order']['goods_no'])->setInc('buynumber');//自动添加购买次数
                Db('Goods')->where('goods_no',$v['order']['goods_no'])->setInc('sale');//自动添加购买次数
                $order['order_info'][$k]['userid'] = $user_id['userid'];
            }
        }

        $order_no = setNumber();

        $order['order_no'] = $order_no;
        $order['status'] = 1;
        $order['name'] = $parameter['name'];
        $order['telphone'] = $parameter['telphone'];
        $order['email'] = $parameter['email'];
        $order['lineid'] = $parameter['lineid'];
        $order['address'] = $parameter['address'];
        $order['country'] = $parameter['detail_city'];
        $order['province'] = $parameter['detail_area'];
        $order['city'] = $parameter['detail_address'];
        $order['payable_amount'] = $parameter['payable_amount'];
        $order['create_time'] = time();
        $order['order_info'] = json_encode($order['order_info']);

        Db::name('order')->insert($order);
        session('shop_car',[]);

        return $this->fetch('pc_sure_money',[
            'order_no'=> $order_no,
        ]);
    }
}
