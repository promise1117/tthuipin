$(function() {

	$('.cart-item__delete').click(function() {
		$('.step,.cart-list,.cart-order-wrap').remove();
		$('.cart-empty').show()
	})






})
