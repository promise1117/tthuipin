<?php /*a:1:{s:71:"/home/wwwroot/www.zishajyw.com/application/index/view/index/slurry.html";i:1585539961;}*/ ?>
<!doctype html>
<html>
	<head>
		<title>泥料</title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<meta data-n-head="ssr" name="keywords" data-hid="keywords" content="">
		<meta data-n-head="ssr" name="description" data-hid="description" content="">

		<link rel="stylesheet" href="/static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
		<link rel="stylesheet" href="/static/index/css/style/7c37c1f9cd04d16fbfdb.css">
		<link rel="stylesheet" href="/static/index/css/style/c4866032732d10b4bdfa.css">
		<link rel="stylesheet" href="/static/index/css/style/8c0b904f195ad20c5f45.css">
		<link rel="stylesheet" href="/static/index/css/style/cf7545887e715f6544b8.css">
	</head>
	<body>
		<div id="app">
			<router-view />
		</div>
		<template id="tem">
			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<div class="my-main-container" data-v-29843982>
							<div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-29843982>
								<div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a  onclick="window.history.back(-1); ">
									<i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a></i>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
								</div>
								<div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>泥料</div>
								<div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a  onclick="location.href='/';">
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
								</div>
							</div>
							<?php if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
									<div data-v-29843982="" style="margin-bottom: 0.53rem; padding: 0 5%;">
									<section data-v-d7fb8786="" data-v-29843982="" style="margin-top: 0.26rem;">
										<div data-v-d7fb8786="" class="header-container">
											<h1 data-v-d7fb8786=""><?php echo htmlentities($v['cat_name']); ?></h1>
											<router-link to="/mud_mixing_<?php echo htmlentities($v['cat_id']); ?>" class="more" data-v-d7fb8786>查看更多</router-link>
											<!-- <a data-v-d7fb8786="" href="mud_mixing" class="more">查看更多</a> -->
										</div>
										<div data-v-d7fb8786="" class="split"></div>
										<div data-v-d7fb8786="" style="padding: 0 0.26rem;">
											<span data-v-d7fb8786="" class="description"><?php echo htmlentities($v['keywords']); ?></span>
											<div data-v-77f4ad42="" data-v-d7fb8786="" class="container" style="margin-top: 0.26rem;">
												<?php if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($v['cat_three']) ? array_slice($v['cat_three'],0,6, true) : $v['cat_three']->slice(0,6, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
												<router-link data-v-77f4ad42="" to="/propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>" class="item">
													<img data-v-77f4ad42="" alt="" src="<?php echo htmlentities($vv['image']); ?>"
													 lazy="loaded">
													<span data-v-77f4ad42=""><?php echo htmlentities($vv['cat_name']); ?></span>
												</router-link>
												<?php endforeach; endif; else: echo "" ;endif; ?>


											</div>
										</div>
									</section>
								</div>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>


					</div>
				</div>
			</div>
		</template>

		<?php if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
			<template id="mud_mixing_<?php echo htmlentities($v['cat_id']); ?>">
				<div id="__nuxt">
					<div id="__layout">
						<div style="max-width:750px;margin:0 auto;">
							<div data-v-568ea247="">
								<div data-v-d09b833a="" data-v-568ea247="" class="van-nav-bar van-hairline--bottom" style="z-index: 1;">
									<div data-v-d09b833a="" class="van-nav-bar__left" onclick="window.history.back(-1); ">
										<i data-v-d09b833a="" class="van-icon van-icon-arrow-left van-nav-bar__arrow"> </i>
										<span data-v-d09b833a="" class="van-nav-bar__text">返回</span>
									</div>
									<div data-v-d09b833a="" class="van-nav-bar__title van-ellipsis"><?php echo htmlentities($v['cat_name']); ?></div>
									<div data-v-d09b833a="" class="van-nav-bar__right" onclick="location.href='/';">
										<span data-v-d09b833a="" class="van-nav-bar__text">首页</span>
									</div>
								</div>
								<div data-v-568ea247="" class="my-main-container" style="padding: 0.26rem 2%;">
									<div data-v-568ea247="" style="padding: 0 0.26rem;">
										<p data-v-568ea247="" class="description"><?php echo htmlentities($v['keywords']); ?></p>
									</div>
									<div data-v-77f4ad42="" data-v-d7fb8786="" class="container" style="margin-top: 0.26rem;">
										<?php if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
										<router-link data-v-77f4ad42="" to="/propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>" class="item">
											<img data-v-77f4ad42="" alt="" src="<?php echo htmlentities($vv['image']); ?>"
											 lazy="loaded">
											<span data-v-77f4ad42=""><?php echo htmlentities($vv['cat_name']); ?></span>
										</router-link>
										<?php endforeach; endif; else: echo "" ;endif; ?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</template>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		<?php endforeach; endif; else: echo "" ;endif; if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
				<template id="propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>">
					<div id="__nuxt">
						<div id="__layout">
							<div style="max-width:750px;margin:0 auto;">
								<div data-v-55ef8ece="">
									<div data-v-d09b833a="" data-v-568ea247="" class="van-nav-bar van-hairline--bottom" style="z-index: 1;">
										<div data-v-d09b833a="" class="van-nav-bar__left" onclick="window.history.back(-1); ">
											<i data-v-d09b833a="" class="van-icon van-icon-arrow-left van-nav-bar__arrow"> </i>
											<span data-v-d09b833a="" class="van-nav-bar__text">返回</span>
										</div>
										<div data-v-d09b833a="" class="van-nav-bar__title van-ellipsis"><?php echo htmlentities($vv['cat_name']); ?></div>
										<div data-v-d09b833a="" class="van-nav-bar__right" onclick="location.href='/';">
											<span data-v-d09b833a="" class="van-nav-bar__text">首页</span>
										</div>
									</div>
									<div data-v-55ef8ece="" class="my-main-container" style="padding: 10px 2%;">
										<div data-v-55ef8ece="" style="padding: 0px 10px;">
											<span data-v-55ef8ece="" class="description">
												<?php echo htmlentities($vv['keywords']); ?>
											</span>
										</div>
										<div data-v-55ef8ece="" class="header-container">
											<h1 data-v-55ef8ece=""><?php echo htmlentities($vv['cat_name']); ?> — 紫砂壶推荐</h1>
										</div>
										<div data-v-55ef8ece="" class="goods_wrap">
											<div data-v-55ef8ece="" class="goods_list">
												<?php if(is_array($vv['link_goods']) || $vv['link_goods'] instanceof \think\Collection || $vv['link_goods'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vv['link_goods'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vvv): $mod = ($i % 2 );++$i;?>
												<div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
													<a data-v-217ef9e2="" href="/goodsinfo?goodsid=<?php echo htmlentities($vvv['id']); ?>" class="goods_avatar_container">
														<img data-v-217ef9e2="" alt="" class="goods_avatar" src="<?php echo htmlentities($vvv['img']); ?>">
													</a>
													<div data-v-217ef9e2="" style="margin-bottom: 10px;">
														<div data-v-217ef9e2="" class="goods_header">
															<span data-v-217ef9e2="" class="goods_name"><?php echo htmlentities($vvv['name']); ?></span>
															<button data-v-217ef9e2="" class="btn_qry">询价</button>
														</div>
														<div data-v-217ef9e2="" class="goods_info">
															<span data-v-217ef9e2="">作者:<?php echo htmlentities($vvv['people_name']); ?></span> <span data-v-217ef9e2="">编号:<?php echo htmlentities($vvv['goods_no']); ?></span>
															<span data-v-217ef9e2="">泥料:<?php echo htmlentities($vvv['mud_name']); ?></span> <span data-v-217ef9e2="">容量:<?php echo htmlentities($vvv['capacity_name']); ?></span>
														</div>
													</div>
												</div>
												<?php endforeach; endif; else: echo "" ;endif; ?>
												<div data-v-55ef8ece="" style="width: 49%;"></div>
											</div>
										</div>
										<div data-v-55ef8ece="" class="header-container">
											<h1 data-v-55ef8ece="">其他泥料推荐</h1>
										</div>
										<div data-v-77f4ad42="" data-v-d7fb8786="" class="container" style="margin-top: 0.26rem;">
											<?php if(is_array($hotlist) || $hotlist instanceof \think\Collection || $hotlist instanceof \think\Paginator): $i = 0; $__LIST__ = $hotlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
											<router-link data-v-77f4ad42="" to="/propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>" class="item">
												<img data-v-77f4ad42="" alt="" src="<?php echo htmlentities($vv['image']); ?>"
												 lazy="loaded">
												<span data-v-77f4ad42=""><?php echo htmlentities($vv['cat_name']); ?></span>
											</router-link>
											<?php endforeach; endif; else: echo "" ;endif; ?>
											<?php endforeach; endif; else: echo "" ;endif; ?>
											<?php endforeach; endif; else: echo "" ;endif; ?>

										</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</template>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		<?php endforeach; endif; else: echo "" ;endif; ?>
		
		<script src="/static/index/lib/jquery/jquery.js"></script>
		<script src="/static/index/js/rem.js"></script>
		<script src="/static/index/lib/vue/vue.min.js"></script>
		<script src="/static/index/lib/vue/vue-router-2.7.0.js"></script>
		<script src="/static/index/lib/swiper/swiper.min4.js"></script>
		<script src="/static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="/static/index/js/common.js"></script>
<!--		<script src="/static/index/js/slurry.js"></script>-->
		<script>
			$(function() {
				const router = new VueRouter({
					routes: [{
						path: '/',
						component: {
							template: '#tem'
						}
					},
						<?php if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
							{
								path: '/mud_mixing_<?php echo htmlentities($v['cat_id']); ?>',
								component: {
									template: '#mud_mixing_<?php echo htmlentities($v['cat_id']); ?>'
								}
							},
							<?php endforeach; endif; else: echo "" ;endif; ?>
						<?php endforeach; endif; else: echo "" ;endif; if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
						{
							path: '/propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>',
							component: {
								template: '#propertyDetail_<?php echo htmlentities($vv['cat_id']); ?>'
							}
						},
						<?php endforeach; endif; else: echo "" ;endif; ?>
						<?php endforeach; endif; else: echo "" ;endif; ?>
						<?php endforeach; endif; else: echo "" ;endif; ?>
						
					]
				})



				const vm = new Vue({
					el: '#app',
					data: {},
					methods: {
						// 询价
						inquiry() {
							$('.consult_body').show();
						},
						close_inquiry() {
							$('.consult_body').hide();
						}
					},
					router,
					components: {
						com: {
							template: '#propertyDetail',
							methods: {
								// 询价
								inquiry() {
									$('.consult_body').show();
								},
								close_inquiry() {
									$('.consult_body').hide();
								}
							},

						},
					},
					created() {

					},
					mounted() {

					}

				})








			})

		</script>
	</body>
</html>
