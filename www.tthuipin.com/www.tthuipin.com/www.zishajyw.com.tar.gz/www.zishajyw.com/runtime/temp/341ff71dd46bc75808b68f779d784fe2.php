<?php /*a:1:{s:78:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\collection.html";i:1584093059;}*/ ?>
<!doctype html>
<html>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="./static/index/css/style/8d9b0e645fdb945bc6c1.css">
		<link rel="stylesheet" href="./static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
		<link rel="stylesheet" href="./static/index/css/style/7c37c1f9cd04d16fbfdb.css">
		<link rel="stylesheet" href="./static/index/css/style/7723a3d357ed6b5ed9e6.css">
	</head>
	<body>
		<div id="app">

			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<section class="container" data-v-326f400f>
							<section data-v-e07e0280 data-v-326f400f>
								<div class="search_navbar" data-v-e07e0280>
									<i class="left van-icon van-icon-arrow-left" style="color:#fff;" data-v-e07e0280 data-v-e07e0280></i>
									<div class="search_container" data-v-e07e0280>
										<svg aria-hidden="true" class="icon icon-search" data-v-e07e0280>
											<use xlink:href="#icon-Search" data-v-e07e0280></use>
										</svg>
										<input type="text" name maxlength="20" placeholder="正宗紫砂壶" data-v-e07e0280>

									</div>
									<a href="/" class="btn_home nuxt-link-active" data-v-e07e0280>
										首页
									</a>
								</div>
							</section>
							<div class="bg_container" data-v-326f400f>
								<ul class="menu_container" data-v-326f400f>
									<li data-v-326f400f>紫砂藏品</li>
									<li data-v-326f400f>瓷器藏品</li>
									<li data-v-326f400f>铁壶藏品</li>
									<li data-v-326f400f>银壶藏品</li>
								</ul>
								<div class="sort_container" data-v-326f400f>
									<ul data-v-326f400f>
										<li class="active" data-v-326f400f><span data-v-326f400f>最新</span></li>
										<li data-v-326f400f><span data-v-326f400f>人气</span></li>
										<li data-v-326f400f><span data-v-326f400f>已结缘</span></li>
									</ul>
								</div>
								<div role="feed" class="van-list" data-v-326f400f>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li class="list__item" data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>

										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
														<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
									<div class="van-list__placeholder"></div>
								</div>
							</div>
						</section>
						<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
							<div class="van-overlay" style="z-index: 2001;"></div>
							<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
								<div data-v-6e32b6c1="" class="popover-bottom">
									<div data-v-6e32b6c1="" class="header">
										<img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
										<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
									<div data-v-6e32b6c1="" class="popover-container">
										<div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
											<span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
											<input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
										</div>
										<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
										<button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
										<div data-v-6e32b6c1="" class="bottomBtn">
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
													<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
												</svg>
												<div data-v-6e32b6c1="">在线客服</div>
											</span>
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
													<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
												</svg>
												<div data-v-6e32b6c1="">微信客服</div>
											</span>
											<a data-v-6e32b6c1="" href="tel:4001168060">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
													<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
												</svg>
												<div data-v-6e32b6c1="">拨打电话</div>
											</a>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
				</div>
			</div>
		</div>
		<!-- 加载中 -->
		<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
			<div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
					 viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
			<div class="van-toast__text">加载中...</div>
		</div>
		<script>
			window.__NUXT__ = (function(a, b) {
				return {
					layout: "default",
					data: [{
						goodsList: [{
							ID: 2825,
							No: "50301",
							Name: "景舟石瓢",
							Capacity: 460,
							AuthorName: "鲍志强",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_50301.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2823,
							No: "41002",
							Name: "彩云追月壶",
							Capacity: 480,
							AuthorName: "鲍仲梅",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_41002.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2821,
							No: "49337",
							Name: "景舟石瓢壶",
							Capacity: 280,
							AuthorName: "徐勤",
							PropertySlurryName: "大红袍",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_49337.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2820,
							No: "37626",
							Name: "腹古菱花壶",
							Capacity: 240,
							AuthorName: "周志新",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_37626.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2816,
							No: "41001",
							Name: "玉佩壶",
							Capacity: 260,
							AuthorName: "鲍仲梅",
							PropertySlurryName: "红泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_41001.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2815,
							No: "59501",
							Name: "吴扣华",
							Capacity: 320,
							AuthorName: "吴扣华",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_59501.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2814,
							No: "21704",
							Name: "禅墩.唯心",
							Capacity: 260,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫朱泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_21704.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}, {
							ID: 2813,
							No: "21703",
							Name: "禅墩.锦葵（还原烧）",
							Capacity: 260,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_21703.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: null,
							PropertyGrade: null,
							Specifications: null,
							TangKouName: null,
							ClassificationName: null,
							OriginName: null,
							MaterialName: null,
							Technology: null,
							Weight: "0",
							Size: null
						}],
						isAllLoaded: a,
						pageIndex: 1
					}],
					error: null,
					state: {
						bottomMenuIndex: 0,
						browserList: [],
						isFirstBrowser: b,
						is2Detail: a,
						isFromDetail: a
					},
					serverRendered: b
				}
			}(false, true));
		</script>
		<script src="./static/index/lib/jquery/jquery.js"></script>
		<script src="./static/index/js/rem.js"></script>
		<script src="./static/index/lib/vue/vue.min.js"></script>
		<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="./static/index/lib/swiper/swiper.min4.js"></script>
		<script src="./static/index/js/collection.js"></script>
	</body>
</html>
