<?php /*a:1:{s:74:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\artist.html";i:1584081428;}*/ ?>
<!doctype html>
<html data-n-head-ssr>
	<head>
		<title>紫砂壶名家大全</title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" type="text/css" href="./static/index/lib/swiper/swiper.min.css">
		<link rel="stylesheet" href="./static/index/css/style/9d9896ea9a96013187ab.css">
		<link rel="stylesheet" href="./static/index/css/style/a874ef5ee6a504758be3.css">
		<link rel="stylesheet" type="text/css" href="./static/index/css/artist.css" />
	</head>
	<body>
		<div data-server-rendered="true" id="__nuxt">
			<!---->
			<div id="__layout">
				<div style="max-width:750px;margin:0 auto;">
					<section style="background:#eee;" data-v-3dd884a8>
						<section data-v-e07e0280 data-v-3dd884a8>
							<div class="search_navbar" data-v-e07e0280>
								<i class="left van-icon van-icon-arrow-left" style="color:#fff;" data-v-e07e0280 data-v-e07e0280></i>
								<div class="search_container" data-v-e07e0280>
									<svg aria-hidden="true" class="icon icon-search" data-v-e07e0280>
										<use xlink:href="#icon-Search" data-v-e07e0280></use>
									</svg>
									<input type="text" name maxlength="20" placeholder="正宗紫砂壶" data-v-e07e0280></div>
								<a href="/" class="btn_home nuxt-link-active" data-v-e07e0280>
									首页
								</a>
							</div>
						</section>


						<!-- Swiper轮播图 -->
						<div class="swiper-container">
							<div class="swiper-wrapper"></div>
							<div class="swiper-pagination"></div>
						</div>

						<ul class="artist_class_container" data-v-3dd884a8>
							<li data-v-3dd884a8><a href="/Artist/list/1013" data-v-3dd884a8>大师 / 研高</a></li>
							<li data-v-3dd884a8><a href="/Artist/list/17" data-v-3dd884a8>高级工艺师</a></li>
							<li data-v-3dd884a8><a href="/Artist/list/16" data-v-3dd884a8>工艺美术师</a></li>
							<li data-v-3dd884a8><a href="/Artist/list/15" data-v-3dd884a8>助理工艺师</a></li>
							<li data-v-3dd884a8><a href="/Artist/list/14" data-v-3dd884a8>工艺美术员</a></li>
							<li data-v-3dd884a8><a href="/Artist/list/1015" data-v-3dd884a8>实力派</a></li>
						</ul>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>大师/研高</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/1013" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>高级工艺师</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/17" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>工艺美术师</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/16" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>助理工艺师</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/15" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>工艺美术员</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/14" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
						<div class="artist_class_title" data-v-3dd884a8>
							<h2 data-v-3dd884a8>实力派</h2>
							<span data-v-3dd884a8>
								<a href="/Artist/list/1015" data-v-3dd884a8>更多&gt;&gt;</a>
							</span>
						</div>
						<div style="padding: 10px;background:#fff;" data-v-3dd884a8>
							<img src="http://static.sxzisha.com/static/大师级别.png" alt style="width: 100%;border-radius: 2px;" data-v-3dd884a8>
							<div class="artist_container" data-v-3dd884a8>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
								<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
									<a href="" data-v-53164fc3>
										<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
										 data-v-53164fc3>
									</a>
									<div class="artist_info" data-v-53164fc3>
										<span class="artist_name" data-v-53164fc3>范泽锋</span>
										<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
									</div>
								</div>
							</div>
						</div>
					</section>


				</div>
			</div>
		</div>
		
		<script src="./static/index/lib/jquery/jquery.js"></script>
		<script src="./static/index/js/rem.js"></script>
		<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="./static/index/lib/swiper/swiper.min4.js" defer=""></script>
		<script src="./static/index/js/artist.js" defer=""></script>
	</body>
</html>
