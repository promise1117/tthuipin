<?php /*a:1:{s:75:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\ambitus.html";i:1584081250;}*/ ?>
<!doctype html>
<html>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="./static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
		<link rel="stylesheet" href="./static/index/css/style/7c37c1f9cd04d16fbfdb.css">
		<link rel="stylesheet" href="./static/index/css/style/96e4362bd4539ba5294e.css">

	</head>
	<body>
		<div id="app">

			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<section class="container" data-v-cb1d9996>
							<div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-cb1d9996>
								<div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a>
									<i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a></i>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
								</div>
								<div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>紫砂周边</div>
								<div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
								</div>
							</div>
							<div class="van-swipe" data-v-cb1d9996>
								<div class="van-swipe-item" style="width:100%;height:100%;transform:translateX(0px);" data-v-cb1d9996>
									<a data-v-cb1d9996>
										<img src="http://static.sxzisha.com/UploadFiles/PictureFiles/紫砂周边_2020_01_19_10_29.png" alt="" style="width:100%;"
										 data-v-cb1d9996>
									</a>
								</div>
							</div>
							<div data-v-cb1d9996>
								<div class="van-sticky">
									<div class="van-tabs van-tabs--line" data-v-cb1d9996>
										<div data-v-cb1d9996="" class="van-tabs van-tabs--line">
											<div class="van-tabs__wrap van-tabs__wrap--scrollable van-hairline--top-bottom">
												<div role="tablist" class="van-tabs__nav van-tabs__nav--line" style="border-color: rgb(221, 128, 26); background: rgb(255, 255, 255);">
													<div role="tab" class="van-tab van-tab--active" style="flex-basis: 22%; color: rgb(102, 102, 102);">
														<span class="van-ellipsis">全部</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="flex-basis: 22%;" aria-selected="true">
														<span class="van-ellipsis">茶叶罐</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="color: rgb(102, 102, 102); flex-basis: 22%;">
														<span class="van-ellipsis">盖杯</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="color: rgb(102, 102, 102); flex-basis: 22%;">
														<span class="van-ellipsis">茶宠</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="color: rgb(102, 102, 102); flex-basis: 22%;">
														<span class="van-ellipsis">雕塑</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="color: rgb(102, 102, 102); flex-basis: 22%;">
														<span class="van-ellipsis">茶盘</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
													<div role="tab" class="van-tab" style="color: rgb(102, 102, 102); flex-basis: 22%;">
														<span class="van-ellipsis">摆件</span>
														<div class="van-tabs__line" style="width: 41.5px; "></div>
													</div>
												</div>
											</div>

										</div>

									</div>
									<div class="sort_container" data-v-cb1d9996>
										<ul data-v-cb1d9996>
											<li class="active" data-v-cb1d9996><span data-v-cb1d9996>最新</span></li>
											<li data-v-cb1d9996><span data-v-cb1d9996>人气</span></li>
										</ul>
									</div>
								</div>
							</div>
							<div role="feed" class="van-list" data-v-cb1d9996>
								<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
									<li data-v-18cf6dfa="">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
													<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
												</div>
											</div>
										</div>
									</li>
									<li data-v-18cf6dfa="">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
													<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
												</div>
											</div>
										</div>
									</li>
									<li data-v-18cf6dfa="">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
													<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
												</div>
											</div>
										</div>
									</li>
									<li class="list__item" data-v-18cf6dfa="">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
													<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
												</div>
											</div>
										</div>
									</li>

									<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
													<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
												</div>
											</div>
										</div>
									</li>
								</ul>
								<div class="van-list__placeholder"></div>
							</div>
						</section>

						<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
							<div class="van-overlay" style="z-index: 2001;"></div>
							<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
								<div data-v-6e32b6c1="" class="popover-bottom">
									<div data-v-6e32b6c1="" class="header">
										<img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
										<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
									<div data-v-6e32b6c1="" class="popover-container">
										<div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
											<span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
											<input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
										</div>
										<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
										<button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
										<div data-v-6e32b6c1="" class="bottomBtn">
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
													<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
												</svg>
												<div data-v-6e32b6c1="">在线客服</div>
											</span>
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
													<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
												</svg>
												<div data-v-6e32b6c1="">微信客服</div>
											</span>
											<a data-v-6e32b6c1="" href="tel:4001168060">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
													<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
												</svg>
												<div data-v-6e32b6c1="">拨打电话</div>
											</a>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
				</div>
			</div>
			<!-- 加载中 -->
			<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
				<div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
						 viewBox="25 25 50 50" class="van-loading__circular">
							<circle cx="50" cy="50" r="20" fill="none"></circle>
						</svg></span></div>
				<div class="van-toast__text">加载中...</div>
			</div>
		</div>
		<script>
			window.__NUXT__ = (function(a, b, c, d, e) {
				return {
					layout: "default",
					data: [{
						classParams: [{
							ID: c,
							Name: "全部",
							ImagePath: a,
							Type: b
						}, {
							ID: 1026,
							Name: "茶叶罐",
							ImagePath: a,
							Type: b
						}, {
							ID: 1027,
							Name: "盖杯",
							ImagePath: a,
							Type: b
						}, {
							ID: 1028,
							Name: "茶宠",
							ImagePath: a,
							Type: b
						}, {
							ID: 1029,
							Name: "雕塑",
							ImagePath: a,
							Type: b
						}, {
							ID: 1030,
							Name: "茶盘",
							ImagePath: a,
							Type: b
						}, {
							ID: 1031,
							Name: "摆件",
							ImagePath: a,
							Type: b
						}, {
							ID: 1032,
							Name: "笔筒",
							ImagePath: a,
							Type: b
						}, {
							ID: 1033,
							Name: "电陶炉",
							ImagePath: a,
							Type: b
						}, {
							ID: 1039,
							Name: "字画",
							ImagePath: a,
							Type: b
						}, {
							ID: 1040,
							Name: "品茗杯",
							ImagePath: a,
							Type: b
						}, {
							ID: 1062,
							Name: "水洗",
							ImagePath: a,
							Type: b
						}, {
							ID: 1063,
							Name: "公道杯",
							ImagePath: a,
							Type: b
						}],
						goodsList: [{
							ID: 2126,
							No: "45104",
							Name: "公道杯",
							Capacity: 300,
							AuthorName: "白雪山",
							PropertySlurryName: "清水泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801181548157072.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2127,
							No: "45105",
							Name: "公道杯",
							Capacity: 300,
							AuthorName: "白雪山",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801181741073686.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2128,
							No: "45106",
							Name: "公道杯",
							Capacity: 280,
							AuthorName: "白雪山",
							PropertySlurryName: "清水泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801181747126326.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2130,
							No: "45108",
							Name: "公道杯",
							Capacity: 400,
							AuthorName: "白雪山",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801181758300337.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2131,
							No: "45109",
							Name: "公道杯",
							Capacity: 350,
							AuthorName: "白雪山",
							PropertySlurryName: "清水泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801181802512146.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2132,
							No: "45110",
							Name: "喜鹊",
							Capacity: "0",
							AuthorName: "白雪山",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801191017535865.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2133,
							No: "45111",
							Name: "喜鹊",
							Capacity: "0",
							AuthorName: "白雪山",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801191026055394.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 2134,
							No: "45112",
							Name: "步步高升",
							Capacity: "0",
							AuthorName: "白雪山",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801191053338021.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: a,
							PropertyGrade: a,
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}],
						isAllLoaded: d,
						ambTab: c,
						pageIndex: 1,
						isInitLoad: e,
						swipeImgs: [{
							Banner: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FPictureFiles\u002F紫砂周边_2020_01_19_10_29.png",
							ImgHyperlink: a
						}]
					}],
					error: a,
					state: {
						bottomMenuIndex: c,
						browserList: [],
						isFirstBrowser: e,
						is2Detail: d,
						isFromDetail: d
					},
					serverRendered: e
				}
			}(null, 3, 0, false, true));
		</script>
		<script src="./static/index/lib/jquery/jquery.js"></script>
		<script src="./static/index/js/rem.js"></script>
		<script src="./static/index/lib/vue/vue.min.js"></script>
		<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="./static/index/lib/swiper/swiper.min4.js"></script>
		<script src="./static/index/js/ambitus.js"></script>
	</body>
</html>
