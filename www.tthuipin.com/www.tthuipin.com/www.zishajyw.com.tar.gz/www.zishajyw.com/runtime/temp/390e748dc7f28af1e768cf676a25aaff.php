<?php /*a:2:{s:75:"/home/wwwroot/www.zishajyw.com/application/index/view/index/collection.html";i:1585475474;s:72:"/home/wwwroot/www.zishajyw.com/application/index/view/public/bottom.html";i:1585472605;}*/ ?>
<!doctype html>
<html>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="/static/index/css/style/8d9b0e645fdb945bc6c1.css">
		<link rel="stylesheet" href="/static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
		<link rel="stylesheet" href="/static/index/css/style/7c37c1f9cd04d16fbfdb.css">
		<link rel="stylesheet" href="/static/index/css/style/7723a3d357ed6b5ed9e6.css">
		<link rel="stylesheet" type="text/css" href="/static/index/css/common.css">

	</head>
	<body>
		<div id="app">

			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<section class="container" data-v-326f400f>
							<section data-v-e07e0280 data-v-326f400f>
								<div class="search_navbar" data-v-e07e0280>
									<i onclick="window.history.back();" class="left van-icon van-icon-arrow-left" style="color:#fff;" data-v-e07e0280 data-v-e07e0280></i>
									<div class="search_container" data-v-e07e0280>
										<svg aria-hidden="true" class="icon icon-search" data-v-e07e0280>
											<use xlink:href="#icon-Search" data-v-e07e0280></use>
										</svg>
										<input type="text" name maxlength="20" placeholder="正宗紫砂壶" data-v-e07e0280>

									</div>
									<a href="/" class="btn_home nuxt-link-active" data-v-e07e0280>
										首页
									</a>
								</div>
							</section>
							<div class="bg_container" data-v-326f400f>
								<ul class="menu_container" data-v-326f400f>
									<li data-v-326f400f>紫砂藏品</li>
									<li data-v-326f400f>瓷器藏品</li>
									<li data-v-326f400f>铁壶藏品</li>
									<li data-v-326f400f>银壶藏品</li>
								</ul>
								<div class="sort_container" data-v-326f400f>
									<ul data-v-326f400f>
										<li class="active" data-v-326f400f><span data-v-326f400f>最新</span></li>
										<li data-v-326f400f><span data-v-326f400f>人气</span></li>
										<li data-v-326f400f><span data-v-326f400f>已结缘</span></li>
									</ul>
								</div>
								<!-- 紫砂藏品-->
								<div role="feed" class="van-list" data-v-326f400f>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										<!--
										<?php if(is_array($hotgoods) || $hotgoods instanceof \think\Collection || $hotgoods instanceof \think\Paginator): $i = 0; $__LIST__ = $hotgoods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
										<li  class="list__item" data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/goodsinfo?goodsid=<?php echo htmlentities($vo['id']); ?>" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="<?php echo htmlentities($vo['img']); ?>">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2=""><?php echo htmlentities($vo['name']); ?></span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:<?php echo htmlentities($vo['people_name']); ?></span> <span data-v-217ef9e2="">编号:<?php echo htmlentities($vo['goods_no']); ?></span>
														<span data-v-217ef9e2="">泥料:<?php echo htmlentities($vo['mud_name']); ?></span> <span data-v-217ef9e2="">容量:<?php echo htmlentities($vo['capacity_name']); ?></span>
													</div>
												</div>
											</div>
										</li>
										<?php endforeach; endif; else: echo "" ;endif; ?>
										-->
										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.img">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">{{item.name}}</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.people_name}}</span> <span data-v-217ef9e2="">编号:{{item.goods_no}}</span>
														<span data-v-217ef9e2="">泥料:{{item.mud_name}}</span> <span data-v-217ef9e2="">容量:{{item.capacity_name}}</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
									<div class="van-list__placeholder"></div>
								</div>
								<!-- 瓷器藏品 -->
								<div role="feed" class="van-list hidden" data-v-326f400f>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										 
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/CiQiGoods/thumbnail_20010641.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">品茗杯</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">瓷器</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/CiQiGoods/thumbnail_20010641.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">品茗杯</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">瓷器</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>

										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
														<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
									<div class="van-list__placeholder"></div>
								</div>
								<!-- 铁壶藏品 -->
								<div role="feed" class="van-list hidden" data-v-326f400f>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										 
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/TieHuGoods/thumbnail_10010001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">一期一会</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">产地:高冈</span>
														<span data-v-217ef9e2="">材质:纯银</span> <span data-v-217ef9e2="">容量:1000L</span>
														<span data-v-217ef9e2="">编号:41001</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/TieHuGoods/thumbnail_10010001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">一期一会</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">产地:高冈</span>
														<span data-v-217ef9e2="">材质:纯银</span> <span data-v-217ef9e2="">容量:1000L</span>
														<span data-v-217ef9e2="">编号:41001</span>
													</div>
												</div>
											</div>
										</li>

										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
														<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
									<div class="van-list__placeholder"></div>
								</div>
								<!-- 银壶藏品 -->
								<div role="feed" class="van-list hidden" data-v-326f400f>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										 
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/TieHuGoods/thumbnail_10010001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">一期一会</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">产地:高冈</span>
														<span data-v-217ef9e2="">材质:纯银</span> <span data-v-217ef9e2="">容量:1000L</span>
														<span data-v-217ef9e2="">重量:890g</span><span data-v-217ef9e2="">工艺:口耳手打出</span>
														<span data-v-217ef9e2="">编号:41001</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="http://static.sxzisha.com/UploadFiles/TieHuGoods/thumbnail_10010001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">一期一会</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">产地:高冈</span>
														<span data-v-217ef9e2="">材质:纯银</span> <span data-v-217ef9e2="">容量:1000L</span>
														<span data-v-217ef9e2="">重量:890g</span><span data-v-217ef9e2="">工艺:口耳手打出</span>
														<span data-v-217ef9e2="">编号:41001</span>
													</div>
												</div>
											</div>
										</li>

										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
														<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
									<div class="van-list__placeholder"></div>
								</div>
							</div>
						</section>
						<section data-v-2e2abbec="" class="bottom" style="height: auto;">
    <div class="van-hairline--top-bottom van-tabbar van-tabbar--fixed" style="z-index:1;" data-v-2e2abbec="">
        <div onclick="window.location.href='/'" class="van-tabbar-item van-tabbar-item--active" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-wap-home">
            </i>

            </div>
            <div class="van-tabbar-item__text">首页</div>
        </div>
        <div onclick="window.location.href='classification'" class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-bars">
            </i>

            </div>
            <div class="van-tabbar-item__text">分类</div>
        </div>
        <div class="van-tabbar-item consult" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><img src="/static/index/img/msg.png" data-v-2e2abbec="">

            </div>
            <div class="van-tabbar-item__text"><span style="color:#D81E06;" data-v-2e2abbec="">咨询</span> </div>
        </div>
        <div class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-eye">
            </i>

            </div>
            <div class="van-tabbar-item__text">发现</div>
        </div>
        <a  class="van-tabbar-item" data-v-2e2abbec="" href="tel:082370808181">
				<div class="van-tabbar-item__icon">
				<i class="van-icon van-icon-phone"> </i>
				</div>
				<div class="van-tabbar-item__text">客服</div>

        </a >
    </div>
</section>
<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
	<div class="van-overlay" style="z-index: 2001;"></div>
	<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
		<div data-v-6e32b6c1="" class="popover-bottom">
			<div data-v-6e32b6c1="" class="header">
				<img data-v-6e32b6c1="" src="/static/index/img/picture/l_logo.png" alt="">
				<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
			<div data-v-6e32b6c1="" class="popover-container">
				<div data-v-6e32b6c1="" class="phone_container" style="margin: 0.26rem 0;">
					<span data-v-6e32b6c1="" style="font-size: 0.42rem;">手机号码：</span>
					<input data-v-6e32b6c1="" class="xjTel" placeholder="请输入您的手机号码" type="number">
				</div>
				<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 0.37rem;">客服人员将在10分钟内回复</span>
				<button data-v-6e32b6c1=""  class="confirm">立即咨询</button>
				<div data-v-6e32b6c1="" class="bottomBtn">
					<span data-v-6e32b6c1="">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
							<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
						</svg>
						<div data-v-6e32b6c1="">在线客服</div>
					</span>
					
					<a data-v-6e32b6c1="" href="tel:082370808181">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
							<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
						</svg>
						<div data-v-6e32b6c1="">拨打电话</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="van-toast van-toast--middle van-toast--fail" style="z-index: 2003;display: none;">
	<i class="van-icon van-icon-fail van-toast__icon"></i>
	<div class="van-toast__text">您输入的手机号码不正确</div>
</div>
<div class="van-toast van-toast--middle van-toast--text" style="z-index: 2004; display: none;">
	<div class="van-toast__text">稍后会有专职人员与您取得联系</div>
</div>

<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
    <div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
            viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
    <div class="van-toast__text">加载中...</div>
</div>
<!-- 返回顶部 -->
<div class="return-top-mobile" style="display: none;">
	<img src="/static/index/img/picture/return_top.png">
</div>
					</div>
				</div>
			</div>
		</div>
		
 		<script src="/static/index/lib/jquery/jquery.js"></script>
		<script src="/static/index/js/rem.js"></script>
		<script src="/static/index/lib/vue/vue.min.js"></script>
		<script src="/static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="/static/index/lib/swiper/swiper.min4.js"></script>
		<script src="/static/index/js/collection.js"></script>
		<script src="/static/index/js/common.js"></script>

	</body>
</html>
