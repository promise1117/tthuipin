<?php /*a:1:{s:81:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\artist_detail.html";i:1584081546;}*/ ?>
<!doctype html>
<html>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<meta data-n-head="ssr" name="keywords" data-hid="keywords" content="">
		<meta data-n-head="ssr" name="description" data-hid="description" content="">
		<link rel="stylesheet" href="./static/index/css/style/3187c1fbb4b739e498e5.css">
		<link rel="stylesheet" href="./static/index/css/style/9d9896ea9a96013187ab.css">
		<link rel="stylesheet" href="./static/index/css/style/5821d16a615f997c7cbf.css">
	</head>
	<body>
		<div id="app">
			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<section data-v-0c97a771>
							<div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-0c97a771>
								<div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a>
									<i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a></i>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
								</div>
								<div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>范泽锋</div>
								<div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
								</div>
							</div>
							<div class="artist_header" data-v-0c97a771>
								<img alt="" class="avatar" data-v-0c97a771 src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201609231437383333.jpg">
								<div class="artist_info" data-v-0c97a771>
									<b style="font-size: 18px;" data-v-0c97a771>范泽锋</b>
									<p class="artist_zc" data-v-0c97a771>研究院高级工艺美术师 宜兴市十佳青年陶艺家</p>
								</div>
							</div>
							<div class="artist_des_container" data-v-0c97a771>
								<div class="artist_des" data-v-0c97a771 style="height: 50px;">
									<div data-v-0c97a771>
										<p style="text-indent:1em;">
											<strong>职称</strong>：
											<strong>
												<span style="color:#E56600;">
													<span style="font-weight:700;color:#666666;font-family:Simsun;font-size:13px;background-color:#EDE9DE;">
														<span style="font-weight:inherit;font-style:inherit;font-family:inherit;vertical-align:baseline;color:#E56600;">研究员级高级工艺美术师</span>
													</span>
												</span>
											</strong>
										</p>
										<p style="text-indent:1em;">
											<strong>范泽锋</strong>，男，
											<strong>
												<a href="" target="_blank">紫砂壶</a>
											</strong>
											艺人、陶瓷艺人、工艺师
										</p>
										<p style="text-indent:1em;">
											<span style="line-height:1.5;">国家高级工艺美术师</span>
										</p>
										<p style="text-indent:1em;"> 江苏省陶瓷艺术大师 </p>
										<p class="MsoNormal" style="text-indent:1em;">
											<span>首届景舟杯金奖得主</span> &nbsp;
										</p>
										<p style="text-indent:1em;"> 无锡市有突出贡献的中青年专家 </p>
										<p style="text-indent:1em;"> 无锡市十大杰出青年 </p>
										<p style="text-indent:1em;"> 陶都宜兴十佳青年陶艺家 </p>
										<p style="text-indent:1em;"> 宜兴市丁蜀镇青年陶艺家联谊会会长 </p>
										<p style="text-indent:1em;"> 宜兴市学术技术带头人 </p>
										<p style="text-indent:1em;"> 陶都宜兴制壶名人 </p>
										<p style="text-indent:1em;"> 龙德堂陶艺创始人 </p>
										<p class="MsoNormal"> <br /> </p>
										<p style="text-indent:1em;">
											<span>范泽锋，又名哲丰，字文成，1976年生于宜兴陶艺世家，2018年研高，江苏省陶瓷艺术大师(2016年
												第二届)，首届“景舟杯”金奖得主，师从省大师范伟群、高工张庆臣、国大师鲍志强。1993年于江苏省丁蜀职业学校紫砂工艺专业班学习毕业。作品以光素精雕艺术见长，其作品多次参加国内外展览屡获大奖。<br /> <br />
												&nbsp;&nbsp;&nbsp;&nbsp;1994年起从事紫砂陶艺创作设计。他所创作的作品可谓具有“精八级，心游万仞、对物通神”的灵感和想象力，造型张弛得度，肖形状物，理趣皆备。在紫砂壶艺的创造过程中，把中国传统文化融合于紫砂作品，尤其把佛文化融合的相得益彰。<br />
												2002年，范泽锋在中国工艺美术造型设计进修班学习结业。<br /> <br />
												&nbsp;&nbsp;&nbsp;&nbsp;作品分别获第一届中国陶瓷艺术展中陶方圆杯银奖，第五届、十五届中国工艺美术大师优秀作品评选金奖，荣获2012创新盛典中国创新设计评选最佳创意奖，首届江苏省陶瓷艺术作品展评金奖，第十届全国陶瓷艺术设计创新评比银奖，第八届中国宜兴国际陶瓷文化艺术节“景舟杯”制壶大赛金奖。并被中南海、中国人民革命军事博物馆、中国现代文学馆、中国首都博物馆、周恩来邓颖超纪念馆等多家艺术团体和个人收藏。<br />
												<br /> &nbsp;&nbsp;&nbsp;&nbsp;曾多次应邀前往英国、韩国、日本、新加坡等陶艺交流。<br />
											</span>
										</p>
										<p> <br /> </p>
										<p> <br /> </p>
									</div>
								</div>
								<div class="artist_collpse" data-v-0c97a771 @click="collpse">
									<svg aria-hidden="true" class="icon icon-Arrowdown" data-v-0c97a771 v-if="more">
										<use xlink:href="#icon-Arrowdown" data-v-0c97a771></use>
									</svg>
									<svg data-v-0c97a771="" aria-hidden="true" class="icon icon-Arrowup" v-else>
										<use data-v-0c97a771="" xlink:href="#icon-Arrowup"></use>
									</svg>
								</div>
							</div>
							<div class="split" data-v-0c97a771></div>
							<div role="feed" class="van-list" data-v-0c97a771>
								<div class="more_goods" data-v-0c97a771>
									<div class="title" data-v-0c97a771>
										<h2 data-v-0c97a771>代表作品</h2>
									</div>
									<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										<li class="list__item" data-v-18cf6dfa="">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
										
										<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
											<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
												<a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
													<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Portrait">
												</a>
												<div style="margin-bottom: 10px;" data-v-217ef9e2="">
													<div class="goods_header" data-v-217ef9e2="">
														<span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
														<button class="btn_qry" data-v-217ef9e2="">询价</button>
													</div>
													<div class="goods_info" data-v-217ef9e2="">
														<span data-v-217ef9e2="">作者:{{item.Name}}</span> <span data-v-217ef9e2="">编号:41001</span>
														<span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
													</div>
												</div>
											</div>
										</li>
									</ul>
								</div>
								<div class="van-list__placeholder"></div>
							</div>
						</section>
						<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
							<div class="van-overlay" style="z-index: 2001;"></div>
							<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
								<div data-v-6e32b6c1="" class="popover-bottom">
									<div data-v-6e32b6c1="" class="header">
										<img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
										<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
									<div data-v-6e32b6c1="" class="popover-container">
										<div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
											<span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
											<input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
										</div>
										<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
										<button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
										<div data-v-6e32b6c1="" class="bottomBtn">
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
													<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
												</svg>
												<div data-v-6e32b6c1="">在线客服</div>
											</span>
											<span data-v-6e32b6c1="">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
													<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
												</svg>
												<div data-v-6e32b6c1="">微信客服</div>
											</span>
											<a data-v-6e32b6c1="" href="tel:4001168060">
												<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
													<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
												</svg>
												<div data-v-6e32b6c1="">拨打电话</div>
											</a>
										</div>
									</div>
								</div>
							</div>
						</section>

					</div>
				</div>
			</div>
		</div>
		<script>
			window.__NUXT__ = (function(a, b) {
				return {
					layout: "default",
					data: [{
						artist: {
							Id: 218,
							Name: "范泽锋",
							Abstracts: "\u003Cp style=\"text-indent:2em;\"\u003E   \u003Cstrong\u003E职称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E\u003Cspan style=\"font-weight:700;color:#666666;font-family:Simsun;font-size:13px;background-color:#EDE9DE;\"\u003E\u003Cspan style=\"font-weight:inherit;font-style:inherit;font-family:inherit;vertical-align:baseline;color:#E56600;\"\u003E研究员级高级工艺美术师\u003C\u002Fspan\u003E\u003C\u002Fspan\u003E\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cstrong\u003E范泽锋\u003C\u002Fstrong\u003E，男，\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E艺人、陶瓷艺人、工艺师。  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cspan style=\"line-height:1.5;\"\u003E国家高级工艺美术师\u003C\u002Fspan\u003E   \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   江苏省陶瓷艺术大师  \u003C\u002Fp\u003E  \u003Cp class=\"MsoNormal\" style=\"text-indent:2em;\"\u003E   \u003Cspan\u003E首届景舟杯金奖得主\u003C\u002Fspan\u003E &nbsp;  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   无锡市有突出贡献的中青年专家  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   无锡市十大杰出青年  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   陶都宜兴十佳青年陶艺家  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   宜兴市丁蜀镇青年陶艺家联谊会会长  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   宜兴市学术技术带头人  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   陶都宜兴制壶名人  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   龙德堂陶艺创始人  \u003C\u002Fp\u003E  \u003Cp class=\"MsoNormal\"\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cspan\u003E范泽锋，又名哲丰，字文成，1976年生于宜兴陶艺世家，2018年研高，江苏省陶瓷艺术大师(2016年 第二届)，首届“景舟杯”金奖得主，师从省大师范伟群、高工张庆臣、国大师鲍志强。1993年于江苏省丁蜀职业学校紫砂工艺专业班学习毕业。作品以光素精雕艺术见长，其作品多次参加国内外展览屡获大奖。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;1994年起从事紫砂陶艺创作设计。他所创作的作品可谓具有“精八级，心游万仞、对物通神”的灵感和想象力，造型张弛得度，肖形状物，理趣皆备。在紫砂壶艺的创造过程中，把中国传统文化融合于紫砂作品，尤其把佛文化融合的相得益彰。\u003Cbr \u002F\u003E  2002年，范泽锋在中国工艺美术造型设计进修班学习结业。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;作品分别获第一届中国陶瓷艺术展中陶方圆杯银奖，第五届、十五届中国工艺美术大师优秀作品评选金奖，荣获2012创新盛典中国创新设计评选最佳创意奖，首届江苏省陶瓷艺术作品展评金奖，第十届全国陶瓷艺术设计创新评比银奖，第八届中国宜兴国际陶瓷文化艺术节“景舟杯”制壶大赛金奖。并被中南海、中国人民革命军事博物馆、中国现代文学馆、中国首都博物馆、周恩来邓颖超纪念馆等多家艺术团体和个人收藏。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;曾多次应邀前往英国、韩国、日本、新加坡等陶艺交流。\u003Cbr \u002F\u003E  \u003C\u002Fspan\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E",
							RichHonorTitle: "研究院高级工艺美术师\r\n宜兴市十佳青年陶艺家",
							RichIntroduce: void 0,
							Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201609231437383333.jpg",
							ArtistLevel: void 0
						},
						goodsList: [{
							ID: 688,
							No: "07011",
							Name: "禅源-花开见佛壶",
							Capacity: 850,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221739018055.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2813,
							No: "21703",
							Name: "禅墩.锦葵（还原烧）",
							Capacity: 260,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_21703.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2814,
							No: "21704",
							Name: "禅墩.唯心",
							Capacity: 260,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫朱泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_21704.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2798,
							No: "21702",
							Name: "经天提梁",
							Capacity: 480,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_21702.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 302,
							No: "07002",
							Name: "蝉墩-唯信",
							Capacity: 300,
							AuthorName: "范泽锋",
							PropertySlurryName: "大红袍",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611101352288915.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1317,
							No: "07020",
							Name: "禅墩-唯本壶",
							Capacity: 520,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221719511773.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1106,
							No: "07017",
							Name: "禅墩`锦葵",
							Capacity: 420,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201703281649571103.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1865,
							No: "07033",
							Name: "禅墩·唯荣壶",
							Capacity: 470,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201710101632413987.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1964,
							No: "07035",
							Name: "景舟石瓢壶（吴东元刻）",
							Capacity: 500,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201711231702207266.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1963,
							No: "07034",
							Name: "禅墩·唯兴",
							Capacity: 360,
							AuthorName: "范泽锋",
							PropertySlurryName: "黄金段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201711101456350027.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2710,
							No: "07049",
							Name: "禅墩·唯心",
							Capacity: 268,
							AuthorName: "范泽锋",
							PropertySlurryName: "朱泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201903151440154016.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2610,
							No: "07043",
							Name: "禅敦唯想壶",
							Capacity: 380,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201901081709354649.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2682,
							No: "07044",
							Name: "禅墩 禅石壶",
							Capacity: 320,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201901141257081552.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2499,
							No: "07042",
							Name: "夜上海壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201811271501043874.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2439,
							No: "07041",
							Name: "禅墩·唯心",
							Capacity: 1000,
							AuthorName: "范泽锋",
							PropertySlurryName: "大红袍",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201808101639351458.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2749,
							No: "07055",
							Name: "禅墩 唯心",
							Capacity: 420,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201907221506513133.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2748,
							No: "07054",
							Name: "禅墩 禅石壶",
							Capacity: 320,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201907151438020128.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2747,
							No: "07053",
							Name: "禅墩 韶华",
							Capacity: 400,
							AuthorName: "范泽锋",
							PropertySlurryName: "黄金段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201907151434436262.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2744,
							No: "07052",
							Name: "禅敦金尊",
							Capacity: 470,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201907081750246804.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1318,
							No: "07021",
							Name: "禅墩-唯德壶",
							Capacity: 400,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221722114171.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1450,
							No: "07028",
							Name: "铜峰叠翠壶",
							Capacity: 320,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_07028.jpeg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1449,
							No: "07027",
							Name: "三足竹壶",
							Capacity: 220,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_07027.jpeg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 303,
							No: "07003",
							Name: "佛心禅意壶(描金)",
							Capacity: 1350,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221744047009.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 304,
							No: "07004",
							Name: "高和壶",
							Capacity: 200,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611101406047432.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 305,
							No: "07005",
							Name: "西施壶",
							Capacity: 180,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611101408296491.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 683,
							No: "07006",
							Name: "禅墩锦葵壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251121373898.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 684,
							No: "07007",
							Name: "禅泉·般若·立相",
							Capacity: 400,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251124376262.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 685,
							No: "07008",
							Name: "佛心禅意壶",
							Capacity: 1350,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251126195403.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 686,
							No: "07009",
							Name: "福禅壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251128219141.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 687,
							No: "07010",
							Name: "国泰民安.威震八方",
							Capacity: 2000,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251130569728.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 689,
							No: "07012",
							Name: "明月清风壶",
							Capacity: 620,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002Fthumbnail_07012.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 690,
							No: "07013",
							Name: "云水三千壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251136558577.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 691,
							No: "07014",
							Name: "真如壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251138145228.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 692,
							No: "07015",
							Name: "智光壶",
							Capacity: 550,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201611251139391950.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1017,
							No: "07016",
							Name: "禅墩锦葵壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201612191112177918.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1319,
							No: "07022",
							Name: "禅墩-唯祥壶",
							Capacity: 330,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221723367661.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1320,
							No: "07023",
							Name: "禅墩-唯宇壶",
							Capacity: 280,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221724262953.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1321,
							No: "07024",
							Name: "禅泉般若立尊壶",
							Capacity: 480,
							AuthorName: "范泽锋",
							PropertySlurryName: "青段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221728387630.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1322,
							No: "07025",
							Name: "佛心禅意壶",
							Capacity: 500,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221729283733.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1323,
							No: "07026",
							Name: "井栏-思源壶",
							Capacity: 420,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201705221731597668.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1691,
							No: "07029",
							Name: "禅墩·唯心壶",
							Capacity: 240,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201812212001224158.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1863,
							No: "07031",
							Name: "自在提梁壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201710101630204245.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 1864,
							No: "07032",
							Name: "妙应无方壶（月照题）",
							Capacity: 420,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201710101631210401.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2254,
							No: "07038",
							Name: "玉琮壶·鲍志强大师陶刻",
							Capacity: 500,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201804231701554669.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2123,
							No: "07036",
							Name: "建盏",
							Capacity: 80,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801171336043898.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2124,
							No: "07037",
							Name: "金油滴建盏",
							Capacity: 190,
							AuthorName: "范泽锋",
							PropertySlurryName: "紫泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201801171336459607.JPG",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2388,
							No: "07039",
							Name: "智慧者壶",
							Capacity: 400,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201806261234470583.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2389,
							No: "07040",
							Name: "禅泉般若立明壶",
							Capacity: 450,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201806261238016439.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2732,
							No: "07051",
							Name: "禅泉般若立明壶",
							Capacity: 420,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201905311546195041.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2730,
							No: "07050",
							Name: "天马行空套壶",
							Capacity: 500,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201905061614505918.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2708,
							No: "07048",
							Name: "禅墩璞光壶",
							Capacity: 350,
							AuthorName: "范泽锋",
							PropertySlurryName: "段泥",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201902271753563050.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2707,
							No: "07047",
							Name: "东陵遗风壶",
							Capacity: 320,
							AuthorName: "范泽锋",
							PropertySlurryName: "黄金段",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201902271753174764.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2706,
							No: "07046",
							Name: "唯政壶",
							Capacity: 400,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201902271752132337.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}, {
							ID: 2683,
							No: "07045",
							Name: "唯心壶",
							Capacity: 320,
							AuthorName: "范泽锋",
							PropertySlurryName: "底槽清",
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaGoods\u002F201901141258005664.jpg",
							Price: void 0,
							Type: 1,
							IsRare: void 0,
							PropertyOrigin: void 0,
							PropertyGrade: void 0,
							Specifications: void 0,
							TangKouName: void 0,
							ClassificationName: void 0,
							OriginName: void 0,
							MaterialName: void 0,
							Technology: void 0,
							Weight: "0",
							Size: void 0
						}],
						isAllLoaded: a,
						pageIndex: 1
					}],
					error: null,
					state: {
						bottomMenuIndex: 0,
						browserList: [],
						isFirstBrowser: b,
						is2Detail: a,
						isFromDetail: a
					},
					serverRendered: b
				}
			}(false, true));
		</script>
		<script src="./static/index/lib/jquery/jquery.js"></script>
		<script src="./static/index/js/rem.js"></script>
		<script src="./static/index/lib/vue/vue.min.js"></script>
		<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="./static/index/lib/swiper/swiper.min4.js"></script>
		<script src="./static/index/js/artist_detail.js"></script>
	</body>
</html>
