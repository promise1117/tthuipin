<?php /*a:2:{s:79:"/home/wwwroot/www.zishajyw.com/application/index/view/index/classification.html";i:1585445467;s:72:"/home/wwwroot/www.zishajyw.com/application/index/view/public/bottom.html";i:1585472605;}*/ ?>
<!doctype html>
<html>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="/static/index/css/style/3187c1fbb4b739e498e5.css">
		<link rel="stylesheet" href="/static/index/css/style/9d9896ea9a96013187ab.css">
		<link rel="stylesheet" href="/static/index/css/style/c5101841da5b20c73fda.css">
		<link rel="stylesheet" type="text/css" href="/static/index/css/common.css">
		<style>

		</style>
	</head>
	<body>
		<div data-server-rendered="true" id="__nuxt">

			<div id="__layout">
				<div style="max-width:750px;margin:0 auto;">
					<section class="full_view" data-v-57ba94be>
						<section data-v-e07e0280 data-v-57ba94be>
							<div class="search_navbar" data-v-e07e0280>
								<i class="left van-icon van-icon-arrow-left" style="color:#fff;" data-v-e07e0280 data-v-e07e0280 onclick="window.history.back()"></i>
								<div class="search_container" data-v-e07e0280>
									<svg aria-hidden="true" class="icon icon-search" data-v-e07e0280>
										<use xlink:href="#icon-Search" data-v-e07e0280></use>
									</svg>
									<input type="text" name maxlength="20" placeholder="正宗紫砂壶" data-v-e07e0280>
								</div>
								<a href="/" class="btn_home nuxt-link-active" data-v-e07e0280>
									首页
								</a>
							</div>
						</section>
						<div class="main_view" data-v-57ba94be>
							<div class="menu_view" data-v-57ba94be>

								<ul class="menu_left" data-v-57ba94be>
									<?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
									<li data-v-57ba94be><span data-v-57ba94be><?php echo htmlentities($vo['cat_name']); ?></span></li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
								</ul>


								<?php if(is_array($catlist) || $catlist instanceof \think\Collection || $catlist instanceof \think\Paginator): $i = 0; $__LIST__ = $catlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
									<div class="menu_right" data-v-57ba94be style="display: none;">
										<?php if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
										<div class="menu_right_item" data-v-57ba94be>

											<div class="submenu_title" data-v-57ba94be>
												<span class="title" data-v-57ba94be><?php echo htmlentities($v['cat_name']); ?></span>
												<a href="" data-v-57ba94be class="hidden">
													<span class="title_more" data-v-57ba94be>全部&gt;&gt;</span>
												</a>
											</div>
											<ul data-v-57ba94be>
												<?php if(is_array($v['cat_three']) || $v['cat_three'] instanceof \think\Collection || $v['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
												<li data-v-57ba94be>
													<a href="/category?cat_id=<?php echo htmlentities($vv['cat_id']); ?>&is_people=<?php echo htmlentities($vv['is_people']); ?>&is_shape=<?php echo htmlentities($vv['is_shape']); ?>&is_capacity=<?php echo htmlentities($vv['is_capacity']); ?>&is_theme=<?php echo htmlentities($vv['is_theme']); ?>&is_mud=<?php echo htmlentities($vv['is_mud']); ?>&is_tealeaf=<?php echo htmlentities($vv['is_tealeaf']); ?>&is_ambitus=<?php echo htmlentities($vv['is_ambitus']); ?>&is_chinaware=<?php echo htmlentities($vv['is_chinaware']); ?>&is_iron_kettle=<?php echo htmlentities($vv['is_iron_kettle']); ?>&is_silver_kettle=<?php echo htmlentities($vv['is_silver_kettle']); ?>" data-v-57ba94be>
														<img src="<?php echo htmlentities($vv['image']); ?>" alt="" data-v-57ba94be>
														<span data-v-57ba94be><?php echo htmlentities($vv['cat_name']); ?></span>
													</a>

												</li>
												<?php endforeach; endif; else: echo "" ;endif; ?>
											</ul>
										</div>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</div>

								<?php endforeach; endif; else: echo "" ;endif; ?>
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">紫泥</span>-->
<!--											<a data-v-57ba94be="" href="" class="">-->
<!--												<span data-v-57ba94be="" class="title_more">全部&gt;&gt;</span>-->
<!--											</a>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?pug=1108" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫泥.png" alt="">-->
<!--													<span data-v-57ba94be="">紫泥</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->

<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">大师/研高</span>-->
<!--											<a data-v-57ba94be="" href=" " class="">-->
<!--												<span data-v-57ba94be="" class="title_more">全部&gt;&gt;</span>-->
<!--											</a>-->
<!--										</div>-->

<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/61" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/曹志刚.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">曹志刚</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/147" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/常月红.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">常月红</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/153" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/范泽洪.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">范泽洪</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/61" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/蒋建军.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">蒋建军</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/147" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/邵美华.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">邵美华</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/153" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/王芳.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">王芳</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/61" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/王品荣.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">王品荣</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/147" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/咸仲英.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">咸仲英</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/Artist/detail/153" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/袁友军.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">袁友军</span>-->
<!--												</a>-->

<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">分类</span>-->
<!--											<a data-v-57ba94be="" href="/shop?capacity=0" class="" <span data-v-57ba94be="" class="title_more">全部&gt;&gt;</span>-->
<!--											</a>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href=" " class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫砂-1.png" alt="">-->
<!--													<span data-v-57ba94be="">150cc以下</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1371" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫砂-7.png" alt="">-->
<!--													<span data-v-57ba94be="">501cc-600cc</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1159" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫砂-2.png" alt="">-->
<!--													<span data-v-57ba94be="">151-200cc</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1161" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫砂-3.png" alt="">-->
<!--													<span data-v-57ba94be="">201-250cc</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1162" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/250-300cc.png" alt="">-->
<!--													<span data-v-57ba94be="">251-300cc</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1163" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/300-400cc.png" alt="">-->
<!--													<span data-v-57ba94be="">301-400cc</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1164" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/400cc以上.png" alt="">-->
<!--													<span data-v-57ba94be="">401cc-500cc</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?capacity=1372" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/紫砂-8.png" alt="">-->
<!--													<span data-v-57ba94be="">700cc以上</span>-->
<!--												</a>-->

<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">分类</span>-->
<!--											<a data-v-57ba94be="" href=" " class="">-->
<!--												<span data-v-57ba94be="" class="title_more">全部&gt;&gt;</span>-->
<!--											</a>-->

<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1099" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/生肖动物.jpg" alt="">-->
<!--													<span data-v-57ba94be="">生肖动物</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1311" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/花鸟.jpg" alt="">-->
<!--													<span data-v-57ba94be="">花鸟</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1329" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/人物.jpg" alt="">-->
<!--													<span data-v-57ba94be="">人物</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1099" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/佛.jpg" alt="">-->
<!--													<span data-v-57ba94be="">佛</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1311" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/风景.jpg" alt="">-->
<!--													<span data-v-57ba94be="">风景</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1329" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/铭文.jpg" alt="">-->
<!--													<span data-v-57ba94be="">铭文</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1099" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/工艺装饰.jpg" alt="">-->
<!--													<span data-v-57ba94be="">工艺装饰</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1311" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/虾.jpg" alt="">-->
<!--													<span data-v-57ba94be="">虾</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1329" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/蟾.jpg" alt="">-->
<!--													<span data-v-57ba94be="">蟾</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop?theme=1329" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/松竹梅.jpg" alt="">-->
<!--													<span data-v-57ba94be="">松竹梅</span>-->
<!--												</a>-->

<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">堂口</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?tangKouID=1411" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/Unknown.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">上野彬郎</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?tangKouID=1412" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/5791db3834ba5_b.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">早川进</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?tangKouID=1413" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/576ba01d3fc1d_b.jpg" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">石黑光南</span>-->
<!--												</a>-->
<!--											</li>-->

<!--										</ul>-->
<!--									</div>-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">产地</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyOrigin=1415" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">京都</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyOrigin=1416" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">高冈</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyOrigin=1417" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">东京</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyOrigin=1418" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">新泻</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">材质</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyMaterial=1419" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">纯银</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyMaterial=1420" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">洋白银</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyMaterial=1421" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">纯金</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/sliverpot/0?propertyMaterial=1422" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/null" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">纯铜</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">堂口</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?tangKouID=1401" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/big-90b20442d0210381f564d359e9da9d07_2017_05_16_16_03_22.jpg"-->
<!--													 alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">云色堂</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?tangKouID=1402" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/d8891a9bc532ca84193d5985efb83ebc.jpg"-->
<!--													 alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">龙文堂</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?tangKouID=1405" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/big-422474ff3f43b1081b3fd4c545ac7b63_2017_05_16_16_02_41.jpg"-->
<!--													 alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">平安松寿堂</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">容量</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1450" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-1.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">1L以下</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1451" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-2.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">1L-1.3L</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1452" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-3.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">1.3L-1.6L</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1453" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-4.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">1.6L-1.9L</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1454" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-5.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">1.9L-2.0L</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ironpot/0?capacity=1455" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/铁壶-6.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">2L以上</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">分类</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1029" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/雕塑.jpg" alt="">-->
<!--													<span data-v-57ba94be="">雕塑</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1026" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/茶叶罐.jpg" alt="">-->
<!--													<span data-v-57ba94be="">茶叶罐</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1031" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/摆件.jpg" alt="">-->
<!--													<span data-v-57ba94be="">摆件</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1029" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/茶盘.jpg" alt="">-->
<!--													<span data-v-57ba94be="">茶盘</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1026" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/笔筒.jpg" alt="">-->
<!--													<span data-v-57ba94be="">笔筒</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1031" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/电陶炉.jpg" alt="">-->
<!--													<span data-v-57ba94be="">电陶炉</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1029" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/盖杯.jpg" alt="">-->
<!--													<span data-v-57ba94be="">盖杯</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1026" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/品茗杯.jpg" alt="">-->
<!--													<span data-v-57ba94be="">品茗杯</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1031" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/水洗.jpg" alt="">-->
<!--													<span data-v-57ba94be="">水洗</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1029" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/茶宠.jpg" alt="">-->
<!--													<span data-v-57ba94be="">茶宠</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1026" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/字画.jpg" alt="">-->
<!--													<span data-v-57ba94be="">字画</span>-->
<!--												</a>-->

<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/ambitus/1031" class="">-->
<!--													<img data-v-57ba94be="" src="/static/index/img/picture/公道杯.jpg" alt="">-->
<!--													<span data-v-57ba94be="">公道杯</span>-->
<!--												</a>-->

<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
<!--								<div class="menu_right" data-v-57ba94be style="display: none;">-->
<!--									<div data-v-57ba94be="" class="menu_right_item">-->
<!--										<div data-v-57ba94be="" class="submenu_title">-->
<!--											<span data-v-57ba94be="" class="title">分类</span>-->
<!--										</div>-->
<!--										<ul data-v-57ba94be="">-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/tea/1036" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/普洱.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">普洱</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/tea/1034" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/红茶.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">红茶</span>-->
<!--												</a>-->
<!--											</li>-->
<!--											<li data-v-57ba94be="">-->
<!--												<a data-v-57ba94be="" href="/shop/tea/1035" class="">-->
<!--													<img data-v-57ba94be="" src="http://static.sxzisha.com/UploadFiles/BaseProperty/白茶.png" alt="">-->
<!--													<span data-v-57ba94be="" class="ellipsis">白茶</span>-->
<!--												</a>-->
<!--											</li>-->
<!--										</ul>-->
<!--									</div>-->
<!--								</div>-->
							</div>
						</div>
					</section>
					<section data-v-2e2abbec="" class="bottom" style="height: auto;">
    <div class="van-hairline--top-bottom van-tabbar van-tabbar--fixed" style="z-index:1;" data-v-2e2abbec="">
        <div onclick="window.location.href='/'" class="van-tabbar-item van-tabbar-item--active" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-wap-home">
            </i>

            </div>
            <div class="van-tabbar-item__text">首页</div>
        </div>
        <div onclick="window.location.href='classification'" class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-bars">
            </i>

            </div>
            <div class="van-tabbar-item__text">分类</div>
        </div>
        <div class="van-tabbar-item consult" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><img src="/static/index/img/msg.png" data-v-2e2abbec="">

            </div>
            <div class="van-tabbar-item__text"><span style="color:#D81E06;" data-v-2e2abbec="">咨询</span> </div>
        </div>
        <div class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-eye">
            </i>

            </div>
            <div class="van-tabbar-item__text">发现</div>
        </div>
        <a  class="van-tabbar-item" data-v-2e2abbec="" href="tel:082370808181">
				<div class="van-tabbar-item__icon">
				<i class="van-icon van-icon-phone"> </i>
				</div>
				<div class="van-tabbar-item__text">客服</div>

        </a >
    </div>
</section>
<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
	<div class="van-overlay" style="z-index: 2001;"></div>
	<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
		<div data-v-6e32b6c1="" class="popover-bottom">
			<div data-v-6e32b6c1="" class="header">
				<img data-v-6e32b6c1="" src="/static/index/img/picture/l_logo.png" alt="">
				<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
			<div data-v-6e32b6c1="" class="popover-container">
				<div data-v-6e32b6c1="" class="phone_container" style="margin: 0.26rem 0;">
					<span data-v-6e32b6c1="" style="font-size: 0.42rem;">手机号码：</span>
					<input data-v-6e32b6c1="" class="xjTel" placeholder="请输入您的手机号码" type="number">
				</div>
				<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 0.37rem;">客服人员将在10分钟内回复</span>
				<button data-v-6e32b6c1=""  class="confirm">立即咨询</button>
				<div data-v-6e32b6c1="" class="bottomBtn">
					<span data-v-6e32b6c1="">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
							<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
						</svg>
						<div data-v-6e32b6c1="">在线客服</div>
					</span>
					
					<a data-v-6e32b6c1="" href="tel:082370808181">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
							<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
						</svg>
						<div data-v-6e32b6c1="">拨打电话</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="van-toast van-toast--middle van-toast--fail" style="z-index: 2003;display: none;">
	<i class="van-icon van-icon-fail van-toast__icon"></i>
	<div class="van-toast__text">您输入的手机号码不正确</div>
</div>
<div class="van-toast van-toast--middle van-toast--text" style="z-index: 2004; display: none;">
	<div class="van-toast__text">稍后会有专职人员与您取得联系</div>
</div>

<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
    <div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
            viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
    <div class="van-toast__text">加载中...</div>
</div>
<!-- 返回顶部 -->
<div class="return-top-mobile" style="display: none;">
	<img src="/static/index/img/picture/return_top.png">
</div>
				</div>
			</div>
		</div>

		<script src="/static/index/lib/jquery/jquery.js"></script>
		<script src="/static/index/js/rem.js"></script>
		<script src="/static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="/static/index/lib/swiper/swiper.min4.js"></script>
		<script src="/static/index/js/common.js"></script>
		<script src="/static/index/js/classification.js"></script>
	</body>
</html>
