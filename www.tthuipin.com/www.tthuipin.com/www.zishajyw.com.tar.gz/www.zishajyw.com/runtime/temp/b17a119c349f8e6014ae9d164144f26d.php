<?php /*a:1:{s:76:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\category.html";i:1583308353;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0025) -->
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>紫砂壶商城</title>
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./static/index/lib/swiper/swiper.min.css">
    <link rel="stylesheet" href="./static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
    <link rel="stylesheet" href="./static/index/css/style/7c37c1f9cd04d16fbfdb.css">
    <link rel="stylesheet" href="./static/index/css/style/9fafd2e043eb519e87e2.css">
    <link rel="stylesheet" href="./static/index/css/style/82f2df4abfc6d48deffe.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/categorylist.css" />

</head>
<body class="">
<div id="__nuxt">
    <div id="__layout">
        <div style="max-width:750px;margin:0 auto;">
            <section class="container" data-v-6fc7e12e="">
                <div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a="" data-v-6fc7e12e="">
                    <div class="van-nav-bar__left" data-v-d09b833a="">
                        <i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a=""></i>
                        <span class="van-nav-bar__text" data-v-d09b833a="">返回</span>
                    </div>
                    <div class="van-nav-bar__title van-ellipsis" data-v-d09b833a="">紫砂商城</div>
                    <div class="van-nav-bar__right" data-v-d09b833a=""><span class="van-nav-bar__text" data-v-d09b833a="">首页</span></div>
                </div>
                <!-- Swiper轮播图 -->
                <div class="swiper-container">
                    <div class="swiper-wrapper"></div>
                    <div class="swiper-pagination"></div>
                </div>
                <div data-v-6fc7e12e="" style="">
                    <div class="van-sticky">
                        <div class="sort_container" data-v-6fc7e12e="">
                            <ul data-v-6fc7e12e="">
                                <li class="sort_tab active" data-v-6fc7e12e=""><span data-v-6fc7e12e="">最新</span></li>
                                <li class="sort_tab" data-v-6fc7e12e="" class=""><span data-v-6fc7e12e="">人气</span></li>
                                <li style="border-left:solid 1px #eee; display: none;" data-v-6fc7e12e="" class="">
                                    <span data-v-6fc7e12e="">筛选</span>
                                    <svg aria-hidden="true" class="icon icon-shaixuan" data-v-6fc7e12e="">
                                        <use xlink:href="#icon-shaixuan" data-v-6fc7e12e=""></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div role="feed" class="van-list" data-v-6fc7e12e="">
                    <ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
                        <li data-v-18cf6dfa="">
                            <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                                <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                    <div class="goods_header" data-v-217ef9e2="">
                                        <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                        <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                    </div>
                                    <div class="goods_info" data-v-217ef9e2="">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-v-18cf6dfa="">
                            <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                                <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                    <div class="goods_header" data-v-217ef9e2="">
                                        <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                        <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                    </div>
                                    <div class="goods_info" data-v-217ef9e2="">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-v-18cf6dfa="">
                            <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                                <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                    <div class="goods_header" data-v-217ef9e2="">
                                        <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                        <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                    </div>
                                    <div class="goods_info" data-v-217ef9e2="">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-v-18cf6dfa="">
                            <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                                <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                    <div class="goods_header" data-v-217ef9e2="">
                                        <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                        <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                    </div>
                                    <div class="goods_info" data-v-217ef9e2="">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>

            <section data-v-6e32b6c1="" class="consult_body" style="display: none;">
                <div class="van-overlay" style="z-index: 2001;"></div>
                <div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
                    <div data-v-6e32b6c1="" class="popover-bottom">
                        <div data-v-6e32b6c1="" class="header">
                            <img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
                            <span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
                        <div data-v-6e32b6c1="" class="popover-container">
                            <div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
                                <span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
                                <input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
                            </div>
                            <span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
                            <button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
                            <div data-v-6e32b6c1="" class="bottomBtn">
										<span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
												<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
											</svg>
											<div data-v-6e32b6c1="">在线客服</div>
										</span>
                                <span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
												<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
											</svg>
											<div data-v-6e32b6c1="">微信客服</div>
										</span>
                                <a data-v-6e32b6c1="" href="tel:4001168060">
                                    <svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
                                        <use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
                                    </svg>
                                    <div data-v-6e32b6c1="">拨打电话</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>


<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2021; display: none;">
    <div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
            viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
    <div class="van-toast__text">加载中...</div>
</div>
<script src="./static/index/lib/jquery/jquery.js"></script>
<script src="./static/index/js/rem.js"></script>
<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
<script src="./static/index/lib/swiper/swiper.min4.js" defer=""></script>
<script src="./static/index/js/categorylist.js" defer=""></script>
</body>
</html>
