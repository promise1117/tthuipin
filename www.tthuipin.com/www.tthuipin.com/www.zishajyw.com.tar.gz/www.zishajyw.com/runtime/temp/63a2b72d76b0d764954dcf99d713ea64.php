<?php /*a:1:{s:79:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\artist_list.html";i:1584081589;}*/ ?>
<!doctype html>
<html data-n-head-ssr>
	<head>
		<title></title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<link rel="stylesheet" href="./static/index/css/style/3187c1fbb4b739e498e5.css">
		<link rel="stylesheet" href="./static/index/css/style/9d9896ea9a96013187ab.css">
		<link rel="stylesheet" href="./static/index/css/style/c5802611ed155f31bd94.css">
	</head>
	<body>

		<div data-server-rendered="true" id="__nuxt">
			<div id="__layout">
				<div style="max-width:750px;margin:0 auto;">
					<section data-v-17476d99>
						<div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-17476d99>
							<div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a>
								<i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a> </i>
								<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
							</div>
							<div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>工艺师</div>
							<div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a>
								<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
							</div>
						</div>
						<div data-v-17476d99>
							<div class="van-sticky">
								<div class="van-tabs van-tabs--line" data-v-17476d99="">
									<div class="van-tabs__wrap van-tabs__wrap--scrollable van-hairline--top-bottom">
										<div role="tablist" class="van-tabs__nav van-tabs__nav--line" style="border-color:#573F40;background:#fff;">
											<div role="tab" data-index = "1" class="van-tab van-tab--active van-ellipsis">
												<span class="van-tab__text">大师 / 研高 </span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
											<div role="tab" data-index = "2" class="van-tab van-ellipsis">
												<span class="van-tab__text">高级工艺师</span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
											<div role="tab" class="van-tab van-ellipsis">
												<span class="van-tab__text">工艺美术师</span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
											<div role="tab" class="van-tab van-ellipsis">
												<span class="van-tab__text">助理工艺师</span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
											<div role="tab" class="van-tab van-ellipsis">
												<span class="van-tab__text">工艺美术员</span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
											<div role="tab" class="van-tab van-ellipsis">
												<span class="van-tab__text">实力派</span>
												<div class="van-tabs__line" style="width: 41.5px; "></div>
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>
						<div id="app">
							<div role="feed" class="van-list" data-v-17476d99>
								<div class="goods_wrap" data-v-17476d99>
									<div class="goods_list" data-v-17476d99>
										<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>
										<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>
										<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>
										<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>
										<div style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>
										<div class="list__item" style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8>
											<a href="" data-v-53164fc3>
												<img alt="" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/portrait_small_061.jpg" class="artist_avatar"
												 data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>范泽锋</span>
												<span class="artist_zc" data-v-53164fc3>研究院高级工艺美术师 宜兴市十佳青年陶艺家</span>
											</div>
										</div>

										<div class="list__item" style="padding:10px 0;width:49%;" data-v-53164fc3 data-v-3dd884a8 v-for="item in goods">
											<a href="" data-v-53164fc3>
												<img alt="" :src="item.Portrait" class="artist_avatar" data-v-53164fc3>
											</a>
											<div class="artist_info" data-v-53164fc3>
												<span class="artist_name" data-v-53164fc3>{{item.Name}}</span>
												<span class="artist_zc" data-v-53164fc3>{{item.RichHonorTitle}}</span>
											</div>
										</div>

									</div>
								</div>
							</div>
					</section>
				</div>
			</div>
		</div>
		</div>
		<!-- 加载中 -->
		<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
			<div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
					 viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
			<div class="van-toast__text">加载中...</div>
		</div>
		<script>
			window.__NUXT__ = (function(a, b) {
				return {
					layout: "default",
					data: [{
						artistList: [{
							ID: 1015,
							Name: "中青实力派",
							ImagePath: "GetImage_jpg.png",
							Data: [{
								Id: 48,
								Name: "王金川",
								Abstracts: "王金川，1968年出生于陶瓷世家，现长龙山庄庄主。1982年走上紫砂陶艺之路，1986年创立金辰陶艺工作室，受到吕尧臣大师的悉心指导，在继承传统制作工艺的基础上，通过研究宜兴出土的拉坯古陶，大胆开发探索失传几百年的宜兴陶土拉坯工艺 ，特别是紫砂珠泥薄胎壶的工艺制作，历尽艰辛，终获成功，成为宜兴紫砂史上珠泥薄胎拉坯壶之创始人。\r\n部分荣誉\r\n2000年作品荣获上海国际茶文化节贵宾指定礼品壶和首届武汉国际茶文化节贵宾指定礼品壶。\r\n2001年应邀参加杭州国际茶文化节，并现场拉坯艺术表演。\r\n2003年 应邀参加广州国际茶文化节，并现场拉坯艺术表演。\r\n2004年 3月应韩国茶道专刊杂志社邀请参加中韩文化交流；4月应上海国际茶文化节日本东京闭幕式邀请到日本参加中日文化交流；为黄新将军书法篆刻作品集《兵经百篇》特制纪念壶；《神灯》、《千秋雪》获第六届中国工艺美术作品评选创新艺术金奖。\r\n2005年《润无声》获中国宜兴国际陶艺展新人新作二等奖。\r\n2005年 6月应邀参加韩国国际茶文化大展并赴韩国高等陶艺学校传授拉坯制壶技艺。\r\n2005年 10月应邀参加韩国济洲国际茶文化祝祭，并进行中韩文化交流。\r\n2005年《陶魂》获第七届中国工艺美术作品评选金奖。\r\n2006年 8月被中国收藏家协会授予“最受欢迎的紫砂艺术大师”荣誉称号。\r\n2007年10月应韩国釜山茶文化展邀请，参加中韩文化交流。\r\n2008年《奥运情》在第九届广州国际茶文化博览会茶具文化创意奖评比中，获得金奖。\r\n2009年《天地人和》在中国宜兴紫砂百名陶瓷艺术家评比活动中获金奖。\r\n2010年《纳福》在“2010河南第二届紫砂艺术节”参展作品评比中，经评审委员会评审荣获创新艺术金奖。\r\n2011年，《潘壶》在中国宜兴陶艺五朵金花北京汇报展中获“中艺杯”银奖，《石瓢》、《一粒珠》获第十三届中国工艺美术作品评选金奖。\r\n2012年《十八罗汉壶》在中国潍坊第五届文化艺术展示交易会评比中荣获金奖。\r\n2013年《神鸟》在瑞典首届中国节上由中国驻瑞典王国大使馆收藏。",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_048.png",
								ArtistLevel: void 0
							}, {
								Id: 107,
								Name: "高旭峰",
								Abstracts: "高旭峰，男，优秀陶艺家，1970年生于宜兴制壶世家，外祖父为著名陶艺名家王寅春。1986年进紫砂培训班学习制壶，1988年进入紫砂工艺厂，师从国家级高级工艺美术师谈跃伟，在制壶技法上也曾受到中国工艺美术大师吕尧臣先生的指点。1996年拜高级工艺美术大师江建翔为师。作品深受紫砂收藏者喜爱。现受聘于方圆堂茗壶制作中心。",
								RichHonorTitle: "紫砂界中青辈顶级高手\r\n\r\n",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_107.jpg",
								ArtistLevel: void 0
							}, {
								Id: 135,
								Name: "陶长辉",
								Abstracts: "毕业于南京师范大学，2006从事紫砂制作，成长过程屡得名师指点，自己凭借对紫砂艺术的热爱，摸索成长之路，以历史为师，以前辈为摹，积极进取，作其作品在全手工大赛中多次得到评委和壶友的欣赏和肯定，累创佳绩。\r\n",
								RichHonorTitle: "2010年荣获全手工制壶大赛三等奖\r\n2011年荣获全手工制壶大赛二等奖\r\n2012年荣获全手工制壶大赛优秀奖\r\n2013年荣获全手工制壶大赛优秀奖\r\n2013年荣获首届荆溪杯大赛二等奖\r\n2015年荣获新人新作大赛三等奖",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_135.jpg",
								ArtistLevel: void 0
							}, {
								Id: 138,
								Name: "孙长书",
								Abstracts: " 　　孙长书，青年实力派陶手。1990年生于安徽。17岁起慕名来宜兴学习紫砂文化，现创立“陶十方紫砂艺术工作室”。师承花器名手谈跃伟，从艺多年，推崇全手工原创，所制花器等作品广受好评，尤其在梅花系列壶的创作设计上更是受到各地藏友的赞赏。作品在江苏省首届全手工壶艺斗壶大赛上斩获得大奖。2010年以来，一直潜心进修紫砂文化，为千姿百态的紫砂艺术增添了新的形式和情趣。",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_138.jpg",
								ArtistLevel: void 0
							}]
						}, {
							ID: 1013,
							Name: "大师\u002F研高",
							ImagePath: "研究员高级工艺师.png",
							Data: [{
								Id: 218,
								Name: "范泽锋",
								Abstracts: "\u003Cp style=\"text-indent:2em;\"\u003E   \u003Cstrong\u003E职称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E\u003Cspan style=\"font-weight:700;color:#666666;font-family:Simsun;font-size:13px;background-color:#EDE9DE;\"\u003E\u003Cspan style=\"font-weight:inherit;font-style:inherit;font-family:inherit;vertical-align:baseline;color:#E56600;\"\u003E研究员级高级工艺美术师\u003C\u002Fspan\u003E\u003C\u002Fspan\u003E\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cstrong\u003E范泽锋\u003C\u002Fstrong\u003E，男，\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E艺人、陶瓷艺人、工艺师。  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cspan style=\"line-height:1.5;\"\u003E国家高级工艺美术师\u003C\u002Fspan\u003E   \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   江苏省陶瓷艺术大师  \u003C\u002Fp\u003E  \u003Cp class=\"MsoNormal\" style=\"text-indent:2em;\"\u003E   \u003Cspan\u003E首届景舟杯金奖得主\u003C\u002Fspan\u003E &nbsp;  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   无锡市有突出贡献的中青年专家  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   无锡市十大杰出青年  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   陶都宜兴十佳青年陶艺家  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   宜兴市丁蜀镇青年陶艺家联谊会会长  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   宜兴市学术技术带头人  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   陶都宜兴制壶名人  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   龙德堂陶艺创始人  \u003C\u002Fp\u003E  \u003Cp class=\"MsoNormal\"\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E  \u003Cp style=\"text-indent:2em;\"\u003E   \u003Cspan\u003E范泽锋，又名哲丰，字文成，1976年生于宜兴陶艺世家，2018年研高，江苏省陶瓷艺术大师(2016年 第二届)，首届“景舟杯”金奖得主，师从省大师范伟群、高工张庆臣、国大师鲍志强。1993年于江苏省丁蜀职业学校紫砂工艺专业班学习毕业。作品以光素精雕艺术见长，其作品多次参加国内外展览屡获大奖。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;1994年起从事紫砂陶艺创作设计。他所创作的作品可谓具有“精八级，心游万仞、对物通神”的灵感和想象力，造型张弛得度，肖形状物，理趣皆备。在紫砂壶艺的创造过程中，把中国传统文化融合于紫砂作品，尤其把佛文化融合的相得益彰。\u003Cbr \u002F\u003E  2002年，范泽锋在中国工艺美术造型设计进修班学习结业。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;作品分别获第一届中国陶瓷艺术展中陶方圆杯银奖，第五届、十五届中国工艺美术大师优秀作品评选金奖，荣获2012创新盛典中国创新设计评选最佳创意奖，首届江苏省陶瓷艺术作品展评金奖，第十届全国陶瓷艺术设计创新评比银奖，第八届中国宜兴国际陶瓷文化艺术节“景舟杯”制壶大赛金奖。并被中南海、中国人民革命军事博物馆、中国现代文学馆、中国首都博物馆、周恩来邓颖超纪念馆等多家艺术团体和个人收藏。\u003Cbr \u002F\u003E  \u003Cbr \u002F\u003E  &nbsp;&nbsp;&nbsp;&nbsp;曾多次应邀前往英国、韩国、日本、新加坡等陶艺交流。\u003Cbr \u002F\u003E  \u003C\u002Fspan\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cbr \u002F\u003E  \u003C\u002Fp\u003E",
								RichHonorTitle: "研究院高级工艺美术师\r\n宜兴市十佳青年陶艺家",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201609231437383333.jpg",
								ArtistLevel: void 0
							}, {
								Id: 61,
								Name: "高海庚",
								Abstracts: "高海庚（1939-1985年），祖籍宜兴丁山小桥南制陶世家。1955年跟随顾景舟学艺，初露才华，深得其师器重，是顾老的得意门生。1960年到中央工艺美术学院专修造型设计，使他学到许多新的造型观念和新的工艺理论知识，同时结识众多专家和艺术界的名流，对其一生的陶瓷艺术创作起到了重要的作用。于1985年12月12日病逝。",
								RichHonorTitle: "制陶世家",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_061.jpg",
								ArtistLevel: void 0
							}, {
								Id: 147,
								Name: "曹婉芬",
								Abstracts: "1940年出生于蜀山镇陶业世家，从小耳濡目染紫砂艺术的熏陶，对紫砂器皿的博制有着特别的感情。\r\n1955年承紫砂花货泰斗朱可心为师，三年学徒打下了全手工制作技法的扎实功底。历经带徒实践、中央工艺美术学院培训，有缘受到裴石民、王寅春、顾景舟等大师、名家的传教，艺术素质得到升华，从业五十多年以来，造就了集各家所长之能，立承前启后之本，创自成一格的艺术特色。一生潜心于紫砂造型设计的研究和制作，创新设计数百件套作品。既不失历史传统文化，又融入了时代文化的理念，在国际及全国陶瓷评比中屡屡获奖，多次赴东南亚各国及港台地区展示及文化交流均受海内外人士的青睐和较高的评价。",
								RichHonorTitle: "中国陶瓷艺术大师（2010年 第二届）\r\n研究员级高级工艺美术师\r\n中国工艺美术学会会员\r\n江苏省工艺美术学会理事\r\n江苏省陶瓷艺术委员会顾问\r\n中国陶瓷艺术、设计、教育终身成就奖",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_147.jpg",
								ArtistLevel: void 0
							}, {
								Id: 153,
								Name: "张红华",
								Abstracts: "张红华，1944年生于宜兴，2005年研高，中国陶瓷艺术大师(2016年 第三届)、江苏省工艺美术大师；师承著名艺人王寅春、紫砂泰斗顾景舟，1958年进紫砂工艺厂学艺，得顾景舟大师长期悉心指导、提携，接受了最高层面的制陶技艺和构思理念的艺术薰陶，融各派精华，自成一格，造形多变，从业紫砂事业50载，前后制造新品100余件套。\r\n七十年代初，正式拜当代壶艺泰斗顾景舟为师，专攻全手工传统制作技法。经大师悉心指导，面名耳提，犹鱼得水、如沐春风，包括从泥料选矿、手工练泥、空手货全手工成型、壶体的造型设计、工艺装饰，到作品烧成及火候气氛的掌握等一系列顾派独门工艺流程，深得真传，熟谙精要，五十年来，尽心抟砂作壶，心摹手追明清、民国诸名家名器，特别是受到其师严谨治壶思想之深刻影响，从而逐渐形成个人雄健而严谨，流畅而规矩，古朴而典雅，传统而又现代的艺术风格，历年来的创作设计和制作能集前人之所长、溶各派之精华，前后推出一百几十件套个人新作，其中不凡有屡获大奖的经典作品，作品既继承王寅春大师的多变手法，娴熟利落，又发扬了顾派艺术倡导的严谨、唯美和周到的哲学艺术思想，从而大大提升了作品的艺术含量，正因如此，较多作品在造型的功能性和制作的艺术性方面得到质的飞路和升华，如制作的《青泉壶》被北京故宫博物馆永久收藏，《上新桥》和《汉园提梁》壶先后两次被中南海紫光阁永久收藏，特别是《提梁石瓢》壶以中国非物质文化遗产项目的代表作为国礼由北大赠送给联合国秘书长苏菲·安南。 \r\n1982年由省职改办审批为助理工艺美术师，1983年选送于中央工艺美术学院造型设计专修班进修，1997年由省轻工业厅授予江苏省工艺美术名人，2005年11月评审为研究员级高级工艺美术师，在继承和发扬紫砂传统工艺，探索具有个人风格的艺术之路上，勇于实践，不断创新，特别是在全手工光素器及竹货的制作成型方面有独到的建树，秉承顾派一贯的传统手法，在此基础上，独创性地开创了具有个人符号特征的设计语言、制作流程，包括各种专用特殊工装工具的制作和使用，熟练运用拍、打、捻、勒、压、搓等地道全手工技法，在保留和宏扬紫砂这一非物质文化遗产精神上，不为名利所驱动，耐得住寂寞，经得起诱惑，几十年来始终坚守全手工制作成型的阵地，并形成了个人独特的人格魅力，赢得业界同行及藏家的尊重，长期来由于特别擅长设计制作光素类作品，所以有幸能与国内众多最顶尖的书画家联袂合作，其中包括：刘海粟、李可染、范曾、费新娥、启功、朱屺赡、张守智、韩美林、韩敏、冯其庸、徐悲鸿夫人廖静文等等，可谓强强联合，真正体现在壶随画贵、字在壶传之精髓，很多作品随同本人一起参加过香港、日本、马来西亚、泰国、新加坡等地的出国展览和访问，引起轰动。\r\n2004年中国当代陶艺名家《张红华紫砂作品集》一书出版；2005年宜兴方圆紫砂有限公司陶娃学紫砂陶瓷系列教材中“玉笠壶”、“双竹提梁壶”，“金铃壶”被选为课本教材；2006年5月23日“提梁石瓢壶”被北京大学收藏，并由许智宏校长作为国礼，赠送来华访问的联合国秘书长安南先生。\r\n所创作的“华天壶”被美国凤凰城美术博物馆收藏；“青泉壶”被北京故宫博物馆收藏；“古玉壶”被英国维多利亚博物馆收藏；“玉笠壶”被无锡市博物馆收藏；“上新桥”和“汉圆提梁”被中国海紫光阁收藏；本人所善述的论文有《紫砂时尚探秘》，《略论紫砂壶艺的历史变迁》，目前编写的《谈紫砂传统工艺的延续和创新》。",
								RichHonorTitle: "中国陶瓷艺术大师\r\n江苏省工艺美术大师\r\n研究员级高级工艺美术师\r\n师从王寅春、顾景舟\r\n中国工艺美术学会会员\r\n江苏省陶瓷艺术委员会名誉理事",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_153.jpg",
								ArtistLevel: void 0
							}]
						}, {
							ID: 17,
							Name: "高级工艺师",
							ImagePath: "工艺师.png",
							Data: [{
								Id: 10,
								Name: "杨小泉",
								Abstracts: "杨小泉，高级工艺美术师，优秀陶艺家，1963年生。外形粗豪，为人谦和，师从研究员级高级工艺美术师陈国良。\r\n自幼对紫砂艺术有浓厚的兴趣，练就了过硬的设计及全手工制壶本领，能于平稳中求动感，流畅中求曲变，传统中求新意。作品先后发表于《壶魂》、《中国当代紫砂百杰集》等书刊，多次获国家级大奖。二十年来专注于朱泥壶的研究，能制朱泥大壶，功力为一般壶艺师所不及。\r\n朱泥是原矿呈金黄色或浅黄绿色的红泥，明代称“石黄泥”，清代称“朱泥”。原矿深埋于宜兴丁山镇赵庄山嫩泥矿层的底部，外观呈咖啡黑色，炼制成泥后称“朱泥”。用热水冲淋朱泥壶，立展娇艳的鲜红色，氤氲中有紫光游移，泡养包浆后红色沉稳。\r\n朱泥因含砂量低（砂乃“泥骨”），泥性娇，支撑度低，成型工艺难度亦高。由生坯至烧成，收缩率高达30%-40%，垂直收缩大于横向收缩，一般成品率为七成，故从古至今常用来制作小件器物和作为化妆土。朱泥含铁量高，烧成温度稍高，即会析出铁质，出现火疵点。\r\n杨小泉擅长全手工制作朱泥作品，其作品全部用原矿朱泥全手工制作而成，可定制。",
								RichHonorTitle: "高级工艺美术师",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_010.jpg",
								ArtistLevel: void 0
							}, {
								Id: 45,
								Name: "吴志平",
								Abstracts: "吴志平，1974年出生于江苏宜兴丁蜀镇，毕业于无锡广播电视大学美术系，南京经贸大学再深造，掌握了扎实的制壶基本功。近20年的艰苦努力，作品日益成熟，形成了自己独特的制陶风格，加之博览诸多佳作，颇有心得，作品继承传统，力求创新，曾多次应邀参展获奖。\r\n       2008年《长城鼎壶》获第十届中国工艺美术大师精品展金奖，\r\n     《君方》获宜兴陶瓷传统制作技艺大赛三等奖\r\n       2009年《玉带》获上海第十一届中国工艺美术大师精品博览会金奖，《语漠情》被宜兴陶瓷博物馆永久收藏，并先后入编各类大型等紫砂书籍。",
								RichHonorTitle: "国家级高级工艺美术师\r\n中国工艺美术学会会员\r\n优秀青年陶艺家",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_045.jpg",
								ArtistLevel: void 0
							}, {
								Id: 98,
								Name: "王秀局",
								Abstracts: "1976年生于江苏省宜兴丁蜀镇，本科文化，就读于南京师范大学美术专业。师从江苏省工艺美术大师邵顺生先生，擅长方器制作，对圆器、素器、筋纹器制作也有一定研究。近几年来，跟随中国工艺美术大师李昌鸿先生学习传统工艺技术，所制作品逐步提高，加之对生活、对美术的理解，逐步形成独特鲜明的个人风格，简洁典雅，形神兼备、线条舒展流畅，在传统的基础上追求创新，功底扎实，选料精细，以严谨的制壶风格，朴实的为人深受壶友喜爱。2013年11月《韵墩》获第十五届中国工艺美术大师精品博览会优秀艺术金奖；2013年11月《无相》获第十五届中国工艺美术大师精品博览会优秀艺术金奖；2014年3月《亚明四方壶》被山东淄博陶瓷馆永久收藏； 2014年5月《紫炉问道》在陶瓷实训基地举办的手工大赛中获二等奖；2014年11月《韵墩》获外观设计专利； 2014年11月《紫炉问道》获外观设计专利；2015年6月《智足提梁》在陶瓷实训基地举办的手工大赛中获一等奖；2015年11月《紫玉金樽壶》在第八届中国宜兴陶瓷文化节“景舟杯”制壶大赛获金奖；2015年11月《紫砂六方陀螺壶》被安徽博物馆永久收藏。\r\n",
								RichHonorTitle: "国家级高级工艺美术师\r\n2015年首届“景舟杯”大赛金奖得主\r\n2015年全手工大赛一等奖得主\r\n中国工艺美术学会会员\r\n江苏省陶瓷行业协会会员",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_098.jpg",
								ArtistLevel: void 0
							}, {
								Id: 109,
								Name: "毛建韦",
								Abstracts: "毛建伟，1981年出生于江苏宜兴丁蜀镇，1998年师从高级工艺美术师袁国强，袁小强兄弟学习全手工制壶技艺。在师傅教导之下系统学习创作，设计，精于各种光器制作技艺。2015年首届“景舟杯”手工制壶大赛中，他的作品“僧帽”壶获得初级组金奖。晋级2017年首届“乡土杯”决赛！",
								RichHonorTitle: "国家级高级工艺美术师\r\n2015年首届“景舟杯”金奖\r\n乡土杯参赛任选\r\n师从高级工艺美术师袁国强、袁小强",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_109.jpg",
								ArtistLevel: void 0
							}]
						}, {
							ID: 15,
							Name: "助理工艺师",
							ImagePath: "助理工艺师.png",
							Data: [{
								Id: 15,
								Name: "崔燕",
								Abstracts: "崔燕，字：雨研，刻绘师从工艺美术大师沈汉生，制壶师从花器名家储彩琴。自幼对紫砂制作耳濡目染，在壶艺方面悟性很高，善于吸取多家大师的特长，融进自己的作品之中。多年来致力于紫砂艺术创作。擅长人物、花鸟的携刻、对制壶品味的追求、泥料的选择达到了精益求精的地步，所制的各式茶壶造型独特、线条流畅、做工细腻严谨、实用中求美观、文雅中求情趣，装饰上以陶刻为主，注重书画韵味，主张刀随笔意，作品融书法、绘画、雕刻、金石、陶艺等多种艺术于一体。作品在各级展览比赛中入展、获奖数十次，入藏多家博物馆，得到了许多专家的好评，深受壶艺爱好者喜爱，被广泛收藏。",
								RichHonorTitle: "国家级助理工艺美术师\r\n\r\n",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_015.jpg",
								ArtistLevel: void 0
							}, {
								Id: 26,
								Name: "潘洪强",
								Abstracts: "潘洪强，一九六九年出生于宜兴丁蜀镇，中国地质大学艺术设计专业本科学历。紫砂世家，从小耳濡目染母亲制壶，酷爱紫砂艺术，艺术的熏陶可谓根深蒂固，对紫砂的认识自幼而来，不断得以升华，对美术的爱好情有独钟，大大提高了对紫砂艺术的认识眼光。师从高级工艺美术师王春明，后又得诸多名人悉心指点，虚心学习，博采众长，风格技艺不拘一格，灵活多变，既得传统之神韵，又具现代之创新，追求的是精气神，讲究的是形功态。\r\n2014年手工制陶大赛荣获三等奖\r\n2015年手工制陶大赛荣获二等奖\r\n2015年首届“景舟杯”制壶大赛中荣获初级组银奖;\r\n2016年手工制陶大赛荣获一等奖; \r\n2017年手工制陶大赛荣获一等奖。",
								RichHonorTitle: "国家级助理工艺美术师\r\n",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_026.jpg",
								ArtistLevel: void 0
							}, {
								Id: 38,
								Name: "孙科",
								Abstracts: "孙科，字（逸羽），沈汉生（石羽）大师入室弟子，优秀青年陶艺家。1981年生，江苏宜兴蜀山人，东南大学本科毕业。拜沈汉生大师为师，先后在中国宜兴紫砂博物馆（紫砂一厂）陶羽轩工作室、大智堂等学习陶刻，制壶，擅长书画陶刻，专工金石；善于设计制壶，专长创作，集书画、诗文、陶刻装饰于一身。其作品深受收藏爱好者的青睐，极具收藏潜能。\r\n2014年佛山陶瓷发表论文浅谈紫砂《中国龙》壶的文化意蕴。\r\n2014年 陶瓷画刊发表论文《茗香壶》的创作内涵浅析。\r\n2014年十六届中国工艺美术大师精品博览会中，《一粒珠》壶获中国工艺美术金奖。\r\n2014《中国龙》壶被宜兴美术馆收藏。",
								RichHonorTitle: "国家助理工艺美术师",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_038.jpg",
								ArtistLevel: void 0
							}, {
								Id: 40,
								Name: "龚杰",
								Abstracts: "龚杰，1986年出生于宜兴丁山，方壶新秀，2015年首届“景舟杯”优秀奖得主，青年陶艺家、高级技师、江苏省陶瓷协会会员。毕业于南京师范大学工艺美术造型设计系，从艺十数载，坚持传统纯手工制壶创作，得华健、潘持平和施小马等紫砂名家悉心指导，作品凭借自身扎实的制壶功底频频创新，既有传统韵味，又具现代艺术特征。",
								RichHonorTitle: "国家助理工艺美术师",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_040.jpg",
								ArtistLevel: void 0
							}]
						}, {
							ID: 16,
							Name: "工艺美术师",
							ImagePath: "GetIge_jpg.png",
							Data: [{
								Id: 72,
								Name: "王智明",
								Abstracts: "1987年出生于紫砂世家 ，其父王福君是高级工艺美术师，江苏省陶瓷艺术名人，王智明从小酷爱书画，其幼年时的绘画作品经常受工艺美术大师谭泉海的指点。受益颇深！2010年六月毕业于江南大学设计系，同年十一月被谭泉海大师收为关门弟子。2018年秋 王智明顺利通过了工艺美术师的考核！其作品细腻古朴，被广大收藏家喜爱！2016年四月，王智明受邀与宜兴陶瓷行业协会史俊堂会长一行前往英国进行艺术交流。其作品在大英博物馆展出并被收藏！王智明也在伦敦大学陶瓷艺术系用英语做了一场精彩的紫砂演讲！    王智明被谭泉海大师收为关门弟子！",
								RichHonorTitle: "国家级工艺美术师 ",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_072.jpg",
								ArtistLevel: void 0
							}, {
								Id: 224,
								Name: "徐伟强",
								Abstracts: "\u003Cp\u003E   \u003Cstrong\u003E&nbsp; &nbsp; 职 &nbsp;称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E国家级助理工艺美术师\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cstrong\u003E徐伟强\u003C\u002Fstrong\u003E，国家助理工艺美术师，徐门紫砂传人，中国美术协会会员，江苏省陶瓷行业协会会员，江苏省紫砂协会会员，著名中青年陶艺家。  \u003C\u002Fp\u003E  \u003Cp\u003E   徐伟强1974年生于陶艺世家，自幼爱好陶艺，师承国家研高、江苏省大师徐元明叔叔。1992年徐伟强进入紫砂工艺厂，接受叔叔(研高)徐元明启蒙，勤学苦练、虚心好学，打下了扎实的制壶及设计茶壶的基础。1995年徐伟强进入中央工艺美术学院进修，后经\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002Fgongyishi.html?category_id=333\" target=\"_blank\"\u003E徐汉棠\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E大师悉心指点紫砂工艺技术和创作设计。思路不断宽阔，作品富于变化，端庄典雅，线条流畅和谐，工艺精巧。 2000年徐伟强创办紫砂工作室，徐伟强\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E作品多次在书籍、报刊上发表，深得海内外收藏家所喜爱并收藏。是紫砂界年轻一代中的一位杰出青年陶艺家。徐伟强紫砂壶代表作《金狮壶》、《葵仿古》、《天地方圆》、《四季如意》等。  \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cstrong\u003E徐伟强\u003C\u002Fstrong\u003E\u003Cstrong\u003E获奖经历：\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   2002年6月 徐伟强紫砂壶作品《竹福壶》荣获中国名茶博览会暨首届碧螺春文化节中国紫砂艺术精品展“银奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2004年 徐伟强紫砂壶作品《莲花水浪壶》荣获第六届中国(国家级)工艺美术大师精品博览会“银奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2004年 徐伟强紫砂壶作品《仿古壶》荣获杭州西湖博览会第五届中国工艺美术大师暨工艺美术精品博览会”金奖“;  \u003C\u002Fp\u003E  \u003Cp\u003E   2005年 徐伟强紫砂壶作品《景山松石瓢壶》荣获第八届中国(国家级)工艺美术大师精品博览会“铜奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2006年 徐伟强紫砂壶作品《福龙壶》荣获第八届中国(国家级)工艺美术大师精品博览会“银奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2006年 徐伟强紫砂壶作品《风顺壶》荣获第八届中国(国家级)工艺美术大师精品博览会“铜奖”。  \u003C\u002Fp\u003E  \u003Cp\u003E   2010年 徐伟强紫砂壶作品《紫砂玉乳壶》被无锡博物馆永久收藏;  \u003C\u002Fp\u003E  \u003Cp\u003E   2010年 徐伟强紫砂壶作品《四季如意壶》在手工制陶大赛中获得“二等奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2011年 徐伟强紫砂壶作品《仿古如意壶》在第十二届中国(国家级)工艺美术大师精品博览会中获得“金奖”;  \u003C\u002Fp\u003E  \u003Cp\u003E   2012年 徐伟强\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E作品《称心如意壶》在手工制陶大赛中获得“二等奖”。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201608091620198071.jpg",
								ArtistLevel: void 0
							}, {
								Id: 228,
								Name: "周益君",
								Abstracts: "\u003Cp\u003E   \u003Cstrong\u003E&nbsp; &nbsp; 职 &nbsp;称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E国家级高级工艺美术师\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cstrong\u003E&nbsp; &nbsp; 周益君\u003C\u002Fstrong\u003E，2013年国家级工艺美术师，1971年生于陶都宜兴，1992年师从高工王福君，后进紫砂研究所，潜心学习，擅长传统造型及全手方器制作。周益君其紫砂壶作品古朴稳重、刚柔方圆、含蓄端庄、精致大度，多次获奖，深受壶友喜爱及推崇，为宜兴青年陶艺家中的实力家！  \u003C\u002Fp\u003E  \u003Cp\u003E   \u003Cbr \u002F\u003E  \u003Cstrong\u003E&nbsp; &nbsp; 周益君紫砂壶\u003C\u002Fstrong\u003E\u003Cstrong\u003E部分荣誉\u003C\u002Fstrong\u003E\u003Cbr \u002F\u003E  \u003Cspan\u003E&nbsp; &nbsp;&nbsp;周益君紫砂壶\u003C\u002Fspan\u003E《僧帽壶》荣获第五届中国工艺美术大师精品展金奖；\u003Cbr \u002F\u003E  \u003Cspan\u003E&nbsp; &nbsp; 周益君紫砂壶\u003C\u002Fspan\u003E《升方壶》荣获第八届中国工艺美术大师精品展金奖。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201608091613076899.jpg",
								ArtistLevel: void 0
							}, {
								Id: 231,
								Name: "陈宗宝",
								Abstracts: "\u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cstrong\u003E职 &nbsp; 称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E国家级工艺美术师\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cstrong\u003E陈宗宝\u003C\u002Fstrong\u003E，\u003Cspan\u003E1979年出生于宜兴紫砂世家，\u003C\u002Fspan\u003E90年随父亲进宜兴紫砂厂工作。94年陈宗宝师从邵家声学习雕塑绘画技艺。96年陈宗宝又师从孙伯春门下学习雕塑技艺。2000年进入龙德堂，得\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002Fgongyishi.html?category_id=111\" target=\"_blank\"\u003E范泽锋\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E先生教泽，学习制壶创作技艺，进修工艺美院陶瓷艺术系，习得精湛技艺，现为龙德堂实力派艺人，著名青年陶艺家。  \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;陈宗宝其\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E作品继承传统，勇于创新，制壶手法细腻，博古承新贯通古今，简洁素雅，大方质朴，将陶器的古拙原味展现，很有质感。善于设计创作，尤擅雕塑装饰。陈宗宝对绘画、篆刻、紫砂史等方面有深入研究。作品集紫砂造型设计与制作，雕塑、装饰、书、画于一体表现形式。从形、神、气、韵、精、功等方面追求效果。以传统艺术为基础，现代美学为理论，从生活中找灵感，在实践中找突破。  \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cspan\u003E陈宗宝\u003C\u002Fspan\u003E紫砂壶造型多变，工精形美。以历史文化融入紫砂艺术的设计思路，形成了鲜明的个人风格。在紫砂艺林中別树一帜。陈宗宝\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E其独立设计制作的作品如《山亭柳》、《兰芝常生》、《一帆风顺》、《时来运转》等深受壶友喜爱，广获好评，升值潜力巨大！曾多次获国内、国际金奖。紫砂壶作品多次被博物馆收藏，并多次举办个人展览。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201804271102499151.jpg",
								ArtistLevel: void 0
							}]
						}, {
							ID: 14,
							Name: "工艺美术员",
							ImagePath: "美术师.png",
							Data: [{
								Id: 46,
								Name: "杭杰",
								Abstracts: "杭杰(杭利强)，1977年出生于宜兴丁山，1995年从艺，壶艺创作和紫砂陶刻皆修。陶刻师从中国陶瓷艺术大师毛国强，制壶师从“壶界四小龙”之一的江建翔。作品风格古朴，手法精湛，均采用上等好泥，令藏家倍加珍爱。潜力巨大！在从事紫砂创作过程中始终谨记师言，传承古意，不忘初心。他认为紫砂文化源远流长，博大精深，必须每个领域都去深入研究学习。“壶之道，初为合用，上为艺术，终为人生”是他内心坚定的宗旨。怀抱对紫砂文化虔诚的敬意，杭杰的作品总是采用上等好泥，精心构思、精工创作，风格古朴，手法精湛，倍受藏家珍爱。其中多个作品被数家博物馆收藏，并多次获得国家级紫砂类比赛金奖。",
								RichHonorTitle: "国家级工艺美术员",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_046.jpg",
								ArtistLevel: void 0
							}, {
								Id: 280,
								Name: "陆彩琴",
								Abstracts: "\u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cstrong\u003E职 &nbsp; 称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E国家级工艺美术员\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cstrong\u003E陆彩琴\u003C\u002Fstrong\u003E，1972年生，江苏宜兴人，优秀青年陶艺家，现为江苏省工艺美术协会会员。陆彩琴自幼对紫砂制作耳濡目染，在壶艺方面悟性很高，善于吸取多家大师的特长，融进自己的\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E作品之中。陆彩琴对制壶品味的追求，紫砂壶泥料的选择达到了精益求精的地步，所制的各式紫砂壶造型独特、线条流畅，得到了许多专家的好评，陆彩琴制作的\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E深受壶艺爱好者喜爱。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201609231428383598.jpg",
								ArtistLevel: void 0
							}, {
								Id: 282,
								Name: "陈伟军",
								Abstracts: "\u003Cp\u003E   &nbsp; &nbsp;&nbsp; &nbsp;\u003Cstrong\u003E职&nbsp; &nbsp;称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E民间艺人\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp;&nbsp; &nbsp;\u003Cstrong\u003E陈伟军\u003C\u002Fstrong\u003E，中国工艺美术学会会员，江苏省青年陶艺家，1969年出生于世界独特的陶都--宜兴丁山人；大多从事紫砂行业\"有的具有先天陶艺的塑养\"、\"有的具有先天制壶的能量\"。  \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp;&nbsp; &nbsp;生在陶都能以优越的环境，具有先辈们的创造与现代人的\"科艺变革\"，具有紫砂泥古雅的色泽和可塑性强的特性来丰富我们的紫砂艺术。  \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp;&nbsp; &nbsp;国伟陶艺主要从事紫砂作品的推广与开发，在制作技艺上进行探索与研究，陈伟军\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E作品以\"工整精细\"\"厚实曲雅\"\"浑然大气\"来满足广大紫砂收藏爱好者的要求为宗旨，同时与各企业及个人塑造紫砂礼品，至今在紫砂艺术界上是一个新的亮点。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002Fportrait_small_281.jpg",
								ArtistLevel: void 0
							}, {
								Id: 284,
								Name: "周锋",
								Abstracts: "\u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;\u003Cstrong\u003E职 &nbsp; 称\u003C\u002Fstrong\u003E：\u003Cstrong\u003E\u003Cspan style=\"color:#E56600;\"\u003E工艺美术员\u003C\u002Fspan\u003E\u003C\u002Fstrong\u003E   \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;周锋，出生在江苏宜兴这处充满艺术灵气的故土，世家从事壶艺，从小受到紫砂艺术的熏陶，对其产生浓厚兴趣。成年后自身丰富的人身阅历，执着追求，练就了制壶方面的综合功力。尤其多年来潜心钻研，对紫砂泥料制作工艺有着深入的摸索和研究。周锋\u003Cspan\u003E\u003Cstrong\u003E\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E\u003C\u002Fstrong\u003E\u003C\u002Fspan\u003E作品融合了传统壶的气度，现代壶的精致，且美观实用，制作的\u003Cspan\u003E紫砂壶\u003C\u002Fspan\u003E受到国内及港澳台各界人士的肯定，多被收藏。  \u003C\u002Fp\u003E  \u003Cp\u003E   &nbsp; &nbsp; &nbsp; &nbsp;周锋\u003Ca href=\"http:\u002F\u002Fwww.sxzisha.com\u002F\" target=\"_blank\"\u003E紫砂壶\u003C\u002Fa\u003E的作品充分表达了作者对紫砂艺术的执着追求，也真正继承和发扬了宜兴紫砂这古老而悠久的文化。  \u003C\u002Fp\u003E",
								RichHonorTitle: "",
								RichIntroduce: void 0,
								Portrait: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FZiShaArtist\u002F201609231541564356.jpg",
								ArtistLevel: void 0
							}]
						}],
						swipeImgs: [{
							Banner: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FPictureFiles\u002F徐勤_2020_01_03_16_05.png",
							ImgHyperlink: "\u002FArtist\u002Fdetail\u002F494"
						}, {
							Banner: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FPictureFiles\u002F董正红_2020_01_03_16_05.png",
							ImgHyperlink: "\u002FArtist\u002Fdetail\u002F286"
						}, {
							Banner: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FPictureFiles\u002F范永军_2020_01_03_16_05.png",
							ImgHyperlink: "\u002FArtist\u002Fdetail\u002F189"
						}]
					}],
					error: null,
					state: {
						bottomMenuIndex: 0,
						browserList: [],
						isFirstBrowser: a,
						is2Detail: b,
						isFromDetail: b
					},
					serverRendered: a
				}
			}(true, false));
		</script>
		<script src="./static/index/lib/jquery/jquery.js"></script>
		<script src="./static/index/js/rem.js"></script>
		<script src="./static/index/lib/vue/vue.min.js"></script>
		<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="./static/index/lib/swiper/swiper.min4.js"></script>
		<script src="./static/index/js/artist_list.js"></script>
	</body>
</html>
