<?php /*a:1:{s:73:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\index.html";i:1583302966;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0022) -->
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>中国紫砂壶商城、聚集紫砂壶名家作品及价格!</title>
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
    <meta data-n-head="ssr" name="keywords" data-hid="keywords" content="紫砂壶">
    <link rel="stylesheet" type="text/css" href="./static/index/lib/swiper/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/style/7c37c1f9cd04d16fbfdb.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/style/ed9b32f681fb3ea5d422.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/index.css">

</head>
<body class="">
<div id="__nuxt">
    <div id="__layout">
        <div style="max-width:750px;margin:0 auto;">
            <section data-v-7a7d1ec7="" class="container">
                <section data-v-500864c6="" data-v-7a7d1ec7="" class="header_container">
                    <img src="" alt="" class="logo" data-v-500864c6>
                    <div data-v-500864c6="" class="search_container">
                        <svg data-v-500864c6="" aria-hidden="true" class="icon icon-search">
                            <use data-v-500864c6="" xlink:href="#icon-Search"></use>
                        </svg>
                        <input data-v-500864c6="" type="text" maxlength="20" placeholder="正宗紫砂壶" class="search_input">
                    </div>
                    <div data-v-500864c6="" class="right">
                        <svg data-v-500864c6="" aria-hidden="true" class="icon icon-touxiang1">
                            <use data-v-500864c6="" xlink:href="#icon-touxiang1"></use>
                        </svg>
                    </div>
                </section>
                <div data-v-7a7d1ec7="" class="menu_container">
                    <ul data-v-7a7d1ec7="" class="menu_ul">
                        <li data-v-7a7d1ec7=""><a data-v-7a7d1ec7="" href="/" class="nuxt-link-exact-active nuxt-link-active">首页</a></li>
                        <li data-v-7a7d1ec7=""><a data-v-7a7d1ec7="" href="/shop" class="">商城</a></li>
                        <li data-v-7a7d1ec7=""><a data-v-7a7d1ec7="" href="/Artist" class="">名家</a></li>
                        <li data-v-7a7d1ec7=""><a data-v-7a7d1ec7="" href="/article/baike" class="">百科</a></li>
                        <li data-v-7a7d1ec7=""><a data-v-7a7d1ec7="" href="/shop/zpg" class="">收藏</a></li>
                        <li data-v-7a7d1ec7="">
                            <a data-v-7a7d1ec7="" href="/shop/classify" class="">
                                <svg data-v-7a7d1ec7="" aria-hidden="true" class="icon icon-caidanguanli">
                                    <use data-v-7a7d1ec7="" xlink:href="#icon-caidanguanli"></use>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
                <div data-v-7a7d1ec7="" role="alert" class="van-notice-bar">
                    <i class="van-icon van-icon-volume-o van-notice-bar__left-icon"> </i>
                    <div role="marquee" class="van-notice-bar__wrap">
                        <div class="van-notice-bar__content van-notice-bar__play--infinite" style="padding-left: 353px; animation-delay: 0s; animation-duration: 15.4541s;">疫情期间，减少出行；在家喝茶，安全暖心。加油武汉！加油中国！</div>
                    </div>
                </div>


                <!-- Swiper轮播图 -->
                <div class="swiper-container">
                    <div class="swiper-wrapper"></div>
                    <div class="swiper-pagination"></div>
                </div>

                <div data-v-7a7d1ec7="" class="navbar_container">
                    <div data-v-7a7d1ec7="" class="van-swipe">
                        <div class="van-swipe__track" style="width: 750px; transition-duration: 0ms; transform: translateX(0px);">
                            <div data-v-7a7d1ec7="" class="van-swipe-item" style="width: 375px; height: 100%; transform: translateX(0px);">
                                <ul data-v-7a7d1ec7="" class="clearfix">
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/zssc.png" alt="">
                                            <span data-v-7a7d1ec7="">紫砂商城</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/Artist" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/mjjs.png" alt="">
                                            <span data-v-7a7d1ec7="">名家介绍</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/zpg" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/zpg.png" alt="">
                                            <span data-v-7a7d1ec7="">珍品馆</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/article/baike/property/1" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/hx.png" alt="">
                                            <span data-v-7a7d1ec7="">壶型</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/article/baike/property/2" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/nl.png" alt="">
                                            <span data-v-7a7d1ec7="">泥料</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/ambitus/0" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/zb.png" alt="">
                                            <span data-v-7a7d1ec7="">紫砂周边</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/tea/0" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/cy.png" alt="">
                                            <span data-v-7a7d1ec7="">茶叶</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/chinaware/0" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/cq.png" alt="">
                                            <span data-v-7a7d1ec7="">瓷器</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/ironpot/0" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/th.png" alt="">
                                            <span data-v-7a7d1ec7="">铁壶</span>
                                        </a>
                                    </li>
                                    <li data-v-7a7d1ec7="">
                                        <a data-v-7a7d1ec7="" href="/shop/sliverpot/0" class="">
                                            <img data-v-7a7d1ec7="" src="./static/index/img/yh.png" alt="">
                                            <span data-v-7a7d1ec7="">银壶</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>

                    <div data-v-7a7d1ec7="" class="menu_tabbar_container" style="display: none;">
                        <div data-v-7a7d1ec7="" class="menu_tabbar">
                            <div data-v-7a7d1ec7="" class="menu_tab position_left"></div>
                        </div>
                    </div>

                </div>
                <div data-v-7a7d1ec7="" class="goods_container">
                    <div data-v-7a7d1ec7="" class="goods_container_header"><span data-v-7a7d1ec7="" class="goods_container_title">限时秒杀</span>
                        <div data-v-7a7d1ec7="" class="goods_container_title_line"></div>
                        <div data-v-7a7d1ec7="" class="goods_container_bg"></div>
                    </div>
                    <div data-v-7a7d1ec7="" class="goods_wrap">
                        <div data-v-7a7d1ec7="" class="" style="padding: 4px; text-align: center; color: rgb(134, 22, 22);">

                        </div>
                        <div data-v-7a7d1ec7="" class="goods_list">
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 0px; width: 32%;">
                                <a data-v-217ef9e2="" href="/shop/product/101?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar_limit" src="./static/index/img/201609201739138160.JPG">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header"><span data-v-217ef9e2="" class="goods_name">仿古壶#2</span>
                                        <button data-v-217ef9e2="">马上抢购</button></div>
                                    <div data-v-217ef9e2="" class="goods_price"><span data-v-217ef9e2="">抢购价:</span> <span data-v-217ef9e2="">680</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-v-7a7d1ec7="" class="goods_container">
                    <div data-v-7a7d1ec7="" class="goods_container_header"><span data-v-7a7d1ec7="" class="goods_container_title">最新上架</span>
                        <div data-v-7a7d1ec7="" class="goods_container_title_line"></div>
                        <div data-v-7a7d1ec7="" class="goods_container_more"><a data-v-7a7d1ec7="" href="/shop" class="">更多&gt;&gt;</a></div>
                    </div>
                    <div data-v-7a7d1ec7="" class="goods_wrap">
                        <div data-v-7a7d1ec7="" class="goods_list">
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-v-7a7d1ec7="" class="goods_container">
                    <div data-v-7a7d1ec7="" class="goods_container_header">
                        <span data-v-7a7d1ec7="" class="goods_container_title">名家介绍</span>
                        <div data-v-7a7d1ec7="" class="goods_container_title_line"></div>
                        <div data-v-7a7d1ec7="" class="goods_container_more">
                            <a data-v-7a7d1ec7="" href="/Artist" class="">更多&gt;&gt;</a>
                        </div>
                    </div>
                    <div data-v-7a7d1ec7="" class="goods_wrap">
                        <div data-v-7a7d1ec7="" class="goods_list">
                            <div data-v-53164fc3="" data-v-7a7d1ec7="" style="padding: 10px 0px; width: 49%;">
                                <a data-v-53164fc3="" href="/Artist/detail/187" class="">
                                    <img data-v-53164fc3="" alt="" class="artist_avatar" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201812071336274854.jpg"></a>
                                <div data-v-53164fc3="" class="artist_info">
                                    <span data-v-53164fc3="" class="artist_name">袁国强</span>
                                    <span data-v-53164fc3="" class="artist_zc"></span>
                                </div>
                            </div>
                            <div data-v-53164fc3="" data-v-7a7d1ec7="" style="padding: 10px 0px; width: 49%;">
                                <a data-v-53164fc3="" href="/Artist/detail/187" class="">
                                    <img data-v-53164fc3="" alt="" class="artist_avatar" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201812071336274854.jpg"></a>
                                <div data-v-53164fc3="" class="artist_info">
                                    <span data-v-53164fc3="" class="artist_name">袁国强</span>
                                    <span data-v-53164fc3="" class="artist_zc"></span>
                                </div>
                            </div>
                            <div data-v-53164fc3="" data-v-7a7d1ec7="" style="padding: 10px 0px; width: 49%;">
                                <a data-v-53164fc3="" href="/Artist/detail/187" class="">
                                    <img data-v-53164fc3="" alt="" class="artist_avatar" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201812071336274854.jpg"></a>
                                <div data-v-53164fc3="" class="artist_info">
                                    <span data-v-53164fc3="" class="artist_name">袁国强</span>
                                    <span data-v-53164fc3="" class="artist_zc"></span>
                                </div>
                            </div>
                            <div data-v-53164fc3="" data-v-7a7d1ec7="" style="padding: 10px 0px; width: 49%;">
                                <a data-v-53164fc3="" href="/Artist/detail/187" class="">
                                    <img data-v-53164fc3="" alt="" class="artist_avatar" src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201812071336274854.jpg"></a>
                                <div data-v-53164fc3="" class="artist_info">
                                    <span data-v-53164fc3="" class="artist_name">袁国强</span>
                                    <span data-v-53164fc3="" class="artist_zc"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-v-7a7d1ec7="" class="goods_container">
                    <div data-v-7a7d1ec7="" class="goods_container_header">
                        <span data-v-7a7d1ec7="" class="goods_container_title">精美珍品</span>
                        <div data-v-7a7d1ec7="" class="goods_container_title_line"></div>
                        <div data-v-7a7d1ec7="" class="goods_container_more">
                            <a data-v-7a7d1ec7="" href="/shop/zpg" class="">更多&gt;&gt;</a>
                        </div>
                    </div>
                    <div data-v-7a7d1ec7="" class="goods_wrap">
                        <div data-v-7a7d1ec7="" class="goods_list">
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-217ef9e2="" data-v-7a7d1ec7="" style="padding: 4px 0px; width: 49%;">
                                <a data-v-217ef9e2="" href="/shop/product/2816?type=1" class="goods_avatar_container">
                                    <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                                </a>
                                <div data-v-217ef9e2="" style="margin-bottom: 10px;">
                                    <div data-v-217ef9e2="" class="goods_header">
                                        <span data-v-217ef9e2="" class="goods_name">玉佩壶</span>
                                        <button data-v-217ef9e2="" class="btn_qry">询价</button>
                                    </div>
                                    <div data-v-217ef9e2="" class="goods_info">
                                        <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                        <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-v-7a7d1ec7="" class="goods_container">
                    <div data-v-7a7d1ec7="" class="goods_container_header">
                        <span data-v-7a7d1ec7="" class="md_title">砂轩紫砂全国连锁门店</span>
                        <div data-v-7a7d1ec7="" class="md_line md_line"></div>
                    </div>
                    <div data-v-7a7d1ec7="" class="md_wrap">
                        <div data-v-7a7d1ec7="" class="md_list">
                            <div data-v-7a7d1ec7="" class="md_item"><span data-v-7a7d1ec7="" class="md_name">上海店</span>
                                <div data-v-7a7d1ec7="" class="md_info">
                                    <p data-v-7a7d1ec7="">地址：上海市</p>
                                    <p data-v-7a7d1ec7="">电话： 082370808181</p>
                                </div>
                            </div>
                        </div> <img src="./static/index/img/zstel1.png" alt="" style="width: 100%;">
                    </div>
                </div>
                <footer data-v-de1f1c82="" data-v-7a7d1ec7="">
                    <p data-v-de1f1c82="" class="partner"> 合作伙伴：中国紫砂协会 江苏省陶瓷行业协会<br data-v-de1f1c82="">
                        <a data-v-de1f1c82="" href="/article/6">紫砂壶最新资讯</a>|
                        <a data-v-de1f1c82="" href="/article/baike/property/2">紫砂壶泥料</a>|
                        <a data-v-de1f1c82="" href="/Artist">紫砂壶名家</a>
                    </p>
                </footer>
            </section>
            <section data-v-2e2abbec="" style="height: auto;">
                <div class="van-hairline--top-bottom van-tabbar van-tabbar--fixed" style="z-index:1;" data-v-2e2abbec="">
                    <div class="van-tabbar-item van-tabbar-item--active" data-v-2e2abbec="" style="color: rgb(134, 22, 22);">
                        <div class="van-tabbar-item__icon"><i class="van-icon van-icon-wap-home">
                        </i>

                        </div>
                        <div class="van-tabbar-item__text">首页</div>
                    </div>
                    <div class="van-tabbar-item" data-v-2e2abbec="">
                        <div class="van-tabbar-item__icon"><i class="van-icon van-icon-bars">
                        </i>

                        </div>
                        <div class="van-tabbar-item__text">分类</div>
                    </div>
                    <div class="van-tabbar-item" data-v-2e2abbec="">
                        <div class="van-tabbar-item__icon"><img src="./static/index/img/msg.png" data-v-2e2abbec="">

                        </div>
                        <div class="van-tabbar-item__text consult"><span style="color:#D81E06;" data-v-2e2abbec="">咨询</span> </div>
                    </div>
                    <div class="van-tabbar-item" data-v-2e2abbec="">
                        <div class="van-tabbar-item__icon"><i class="van-icon van-icon-eye">
                        </i>

                        </div>
                        <div class="van-tabbar-item__text">发现</div>
                    </div>
                    <div class="van-tabbar-item" data-v-2e2abbec="">
                        <div class="van-tabbar-item__icon"><i class="van-icon van-icon-phone">
                        </i>

                        </div>
                        <div class="van-tabbar-item__text">客服</div>
                    </div>
                </div>
            </section>
            <section data-v-6e32b6c1="" class="consult_body" style="display: none;">
                <div class="van-overlay" style="z-index: 2001;"></div>
                <div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
                    <div data-v-6e32b6c1="" class="popover-bottom">
                        <div data-v-6e32b6c1="" class="header">
                            <img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
                            <span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
                        <div data-v-6e32b6c1="" class="popover-container">
                            <div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
                                <span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
                                <input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
                            </div>
                            <span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
                            <button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
                            <div data-v-6e32b6c1="" class="bottomBtn">
										<span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
												<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
											</svg>
											<div data-v-6e32b6c1="">在线客服</div>
										</span>
                                <span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
												<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
											</svg>
											<div data-v-6e32b6c1="">微信客服</div>
										</span>
                                <a data-v-6e32b6c1="" href="tel:4001168060">
                                    <svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
                                        <use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
                                    </svg>
                                    <div data-v-6e32b6c1="">拨打电话</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>



<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
    <div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
            viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
    <div class="van-toast__text">加载中...</div>
</div>
<script src="./static/index/lib/jquery/jquery.js"></script>
<script src="./static/index/js/rem.js"></script>
<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
<script src="./static/index/lib/swiper/swiper.min4.js" defer=""></script>
<script src="./static/index/js/index.js" defer=""></script>
</body>
</html>
