<?php /*a:2:{s:72:"/home/wwwroot/www.zishajyw.com/application/index/view/index/tealeaf.html";i:1585450904;s:72:"/home/wwwroot/www.zishajyw.com/application/index/view/public/bottom.html";i:1585472605;}*/ ?>
<!doctype html>
<html>
	<head>
		<title>茶叶</title>
		<meta data-n-head="ssr" charset="utf-8">
		<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
		<meta data-n-head="ssr" name="keywords" data-hid="keywords" content="">
		<meta data-n-head="ssr" name="description" data-hid="description" content="">

		<link rel="stylesheet" href="/static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
		<link rel="stylesheet" href="/static/index/css/style/7c37c1f9cd04d16fbfdb.css">
		<link rel="stylesheet" href="/static/index/css/style/a563b2e46ceb6127140a.css">
		<link rel="stylesheet" type="text/css" href="/static/index/css/common.css">
		<style type="text/css">
			.van-tab {
				color: rgb(255, 255, 255);
			}

			.van-tab--active {
				color: #323233;
				font-weight: bold;
			}

			.van-tab--active .van-tabs__line {
				width: 50%;
				background-color: rgb(202, 213, 57);
			}
		</style>
	</head>
	<body>
		<div id="app">
			<div data-server-rendered="true" id="__nuxt">
				<div id="__layout">
					<div style="max-width:750px;margin:0 auto;">
						<section class="container" data-v-10eb62d9>
							<div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-cb1d9996>
								<div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a>
									<i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a></i>
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
								</div>
								<div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>茶叶</div>
								<div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a onclick="window.location.href='/'">
									<span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
								</div>
							</div>
							<div class="van-swipe" data-v-cb1d9996>
								<div class="van-swipe-item" style="width:100%;height:100%;transform:translateX(0px);" data-v-cb1d9996>
									<a data-v-cb1d9996>
										<img src="http://static.sxzisha.com/UploadFiles/PictureFiles/茶叶banner_2020_01_03_16_20.png" alt="" style="width:100%;"
										 data-v-cb1d9996>
									</a>
								</div>
							</div>
							<div data-v-10eb62d9="">
								<div class="van-sticky">
									<div data-v-10eb62d9="" class="van-tabs van-tabs--line">
										<div class="van-tabs__wrap van-hairline--top-bottom">
											<div role="tablist" class="van-tabs__nav van-tabs__nav--line" style="border-color: rgb(202, 213, 57); background: rgb(115, 117, 65);">
												<div role="tab" class="van-tab  van-tab--active" aria-selected="true">
													<span class="van-ellipsis">全部</span>
													<div class="van-tabs__line"></div>
												</div>
												<?php if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(is_array($vo['cat_two']) || $vo['cat_two'] instanceof \think\Collection || $vo['cat_two'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['cat_two'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;if(is_array($vv['cat_three']) || $vv['cat_three'] instanceof \think\Collection || $vv['cat_three'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vv['cat_three'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vvv): $mod = ($i % 2 );++$i;?>
												<div role="tab" class="van-tab">
													<span class="van-ellipsis"><?php echo htmlentities($vvv['cat_name']); ?></span>
													<div class="van-tabs__line"></div>
												</div>
												<?php endforeach; endif; else: echo "" ;endif; ?>
												<?php endforeach; endif; else: echo "" ;endif; ?>
												<?php endforeach; endif; else: echo "" ;endif; ?>
<!--												<div role="tab" class="van-tab">-->
<!--													<span class="van-ellipsis">白茶</span>-->
<!--													<div class="van-tabs__line"></div>-->
<!--												</div>-->
<!--												<div role="tab" class="van-tab">-->
<!--													<span class="van-ellipsis">普洱</span>-->
<!--													<div class="van-tabs__line"></div>-->
<!--												</div>-->
<!--												<div class="van-tabs__line" style="background-color: rgb(202, 213, 57); width: 47px; transform: translateX(328px) translateX(-50%); transition-duration: 0.3s;"></div>-->
											</div>
										</div>
										<div class="van-tabs__content">
											<div data-v-10eb62d9="" role="tabpanel" class="van-tab__pane" style="display: none;"></div>
											<div data-v-10eb62d9="" role="tabpanel" class="van-tab__pane" style="display: none;"></div>
											<div data-v-10eb62d9="" role="tabpanel" class="van-tab__pane" style="display: none;"></div>
											<div data-v-10eb62d9="" role="tabpanel" class="van-tab__pane"></div>
										</div>
									</div>
									<div data-v-10eb62d9="" class="sort_container">
										<ul data-v-10eb62d9="">
											<li data-v-10eb62d9="" class="active"><span data-v-10eb62d9="">最新</span></li>
											<li data-v-10eb62d9="" class=""><span data-v-10eb62d9="">人气</span></li>
										</ul>
									</div>
								</div>
							</div>
							<div role="feed" class="van-list" data-v-cb1d9996>
								<ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
									<?php if(is_array($hotgoods) || $hotgoods instanceof \think\Collection || $hotgoods instanceof \think\Paginator): $i = 0; $__LIST__ = $hotgoods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
									<li class="list__item" data-v-18cf6dfa="">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="/goodsinfo?goodsid=<?php echo htmlentities($vo['id']); ?>" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" src="<?php echo htmlentities($vo['img']); ?>">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2=""><?php echo htmlentities($vo['name']); ?></span>
													<button class="btn_qry" data-v-217ef9e2="">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:<?php echo htmlentities($vo['people_name']); ?></span> <span data-v-217ef9e2="">编号:<?php echo htmlentities($vo['goods_no']); ?></span>
													<span data-v-217ef9e2="">泥料:<?php echo htmlentities($vo['mud_name']); ?></span> <span data-v-217ef9e2="">容量:<?php echo htmlentities($vo['capacity_name']); ?></span>
												</div>
											</div>
										</div>
									</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
									<li class="list__item" data-v-18cf6dfa="" v-for="item in goods">
										<div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
											<a href="" class="goods_avatar_container" data-v-217ef9e2="">
												<img data-v-217ef9e2="" alt="" class="goods_avatar" :src="item.Thumbnail">
											</a>
											<div style="margin-bottom: 10px;" data-v-217ef9e2="">
												<div class="goods_header" data-v-217ef9e2="">
													<span class="goods_name" data-v-217ef9e2="">{{item.Name}}</span>
													<button class="btn_qry" data-v-217ef9e2="" @click="inquiry">询价</button>
												</div>
												<div class="goods_info" data-v-217ef9e2="">
													<span data-v-217ef9e2="">作者:{{item.AuthorName}}</span> <span data-v-217ef9e2="">编号:{{item.No}}</span>
													<span data-v-217ef9e2="">泥料:{{item.PropertySlurryName}}</span> <span data-v-217ef9e2="">容量:{{item.Capacity}}cc</span>
												</div>
											</div>
										</div>
									</li>
								</ul>
								<div class="van-list__finished-text">没有更多了</div>
								<div class="van-list__placeholder"></div>
							</div>
						</section>

						   <section data-v-2e2abbec="" class="bottom" style="height: auto;">
    <div class="van-hairline--top-bottom van-tabbar van-tabbar--fixed" style="z-index:1;" data-v-2e2abbec="">
        <div onclick="window.location.href='/'" class="van-tabbar-item van-tabbar-item--active" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-wap-home">
            </i>

            </div>
            <div class="van-tabbar-item__text">首页</div>
        </div>
        <div onclick="window.location.href='classification'" class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-bars">
            </i>

            </div>
            <div class="van-tabbar-item__text">分类</div>
        </div>
        <div class="van-tabbar-item consult" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><img src="/static/index/img/msg.png" data-v-2e2abbec="">

            </div>
            <div class="van-tabbar-item__text"><span style="color:#D81E06;" data-v-2e2abbec="">咨询</span> </div>
        </div>
        <div class="van-tabbar-item" data-v-2e2abbec="">
            <div class="van-tabbar-item__icon"><i class="van-icon van-icon-eye">
            </i>

            </div>
            <div class="van-tabbar-item__text">发现</div>
        </div>
        <a  class="van-tabbar-item" data-v-2e2abbec="" href="tel:082370808181">
				<div class="van-tabbar-item__icon">
				<i class="van-icon van-icon-phone"> </i>
				</div>
				<div class="van-tabbar-item__text">客服</div>

        </a >
    </div>
</section>
<section data-v-6e32b6c1="" class="consult_body" style="display: none;">
	<div class="van-overlay" style="z-index: 2001;"></div>
	<div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
		<div data-v-6e32b6c1="" class="popover-bottom">
			<div data-v-6e32b6c1="" class="header">
				<img data-v-6e32b6c1="" src="/static/index/img/picture/l_logo.png" alt="">
				<span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
			<div data-v-6e32b6c1="" class="popover-container">
				<div data-v-6e32b6c1="" class="phone_container" style="margin: 0.26rem 0;">
					<span data-v-6e32b6c1="" style="font-size: 0.42rem;">手机号码：</span>
					<input data-v-6e32b6c1="" class="xjTel" placeholder="请输入您的手机号码" type="number">
				</div>
				<span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 0.37rem;">客服人员将在10分钟内回复</span>
				<button data-v-6e32b6c1=""  class="confirm">立即咨询</button>
				<div data-v-6e32b6c1="" class="bottomBtn">
					<span data-v-6e32b6c1="">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
							<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
						</svg>
						<div data-v-6e32b6c1="">在线客服</div>
					</span>
					
					<a data-v-6e32b6c1="" href="tel:082370808181">
						<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
							<use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
						</svg>
						<div data-v-6e32b6c1="">拨打电话</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="van-toast van-toast--middle van-toast--fail" style="z-index: 2003;display: none;">
	<i class="van-icon van-icon-fail van-toast__icon"></i>
	<div class="van-toast__text">您输入的手机号码不正确</div>
</div>
<div class="van-toast van-toast--middle van-toast--text" style="z-index: 2004; display: none;">
	<div class="van-toast__text">稍后会有专职人员与您取得联系</div>
</div>

<div class="van-toast van-toast--middle van-toast--loading" style="z-index: 2003; display: none; ">
    <div class="van-loading van-loading--circular van-toast__loading"><span class="van-loading__spinner van-loading__spinner--circular"><svg
            viewBox="25 25 50 50" class="van-loading__circular">
						<circle cx="50" cy="50" r="20" fill="none"></circle>
					</svg></span></div>
    <div class="van-toast__text">加载中...</div>
</div>
<!-- 返回顶部 -->
<div class="return-top-mobile" style="display: none;">
	<img src="/static/index/img/picture/return_top.png">
</div>
					</div>
				</div>
			</div>
			
		</div>
		<script>
			window.__NUXT__ = (function(a, b, c, d, e) {
				return {
					layout: "default",
					data: [{
						classParams: [{
							ID: c,
							Name: "全部",
							ImagePath: a,
							Type: b
						}, {
							ID: 1034,
							Name: "红茶",
							ImagePath: a,
							Type: b
						}, {
							ID: 1035,
							Name: "白茶",
							ImagePath: a,
							Type: b
						}, {
							ID: 1036,
							Name: "普洱",
							ImagePath: a,
							Type: b
						}],
						goodsList: [{
							ID: 7,
							No: "80006",
							Name: "2011年寿眉",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80006.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "福建",
							PropertyGrade: "白茶",
							Specifications: "100克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 9,
							No: "80008",
							Name: "昔归茶",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80008.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "生普",
							Specifications: "200克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 10,
							No: "80009",
							Name: "冰岛茶",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80009.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "生普",
							Specifications: "200克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 11,
							No: "800010",
							Name: "老班章",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_800010.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "生普",
							Specifications: "357克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 12,
							No: "80011",
							Name: "高原七子饼",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80011.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "熟普",
							Specifications: "357克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 13,
							No: "80012",
							Name: "冰岛普洱茶",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80012.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "生普",
							Specifications: "357克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 14,
							No: "80013",
							Name: "大红袍肉桂",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80013.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "福建",
							PropertyGrade: "红茶",
							Specifications: "500克",
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}, {
							ID: 16,
							No: "80015",
							Name: "野生普洱",
							Capacity: "0",
							AuthorName: a,
							PropertySlurryName: a,
							Thumbnail: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FTeaGoods\u002Fthumbnail_80015.jpg",
							Price: void 0,
							Type: b,
							IsRare: void 0,
							PropertyOrigin: "云南",
							PropertyGrade: "普洱",
							Specifications: a,
							TangKouName: a,
							ClassificationName: a,
							OriginName: a,
							MaterialName: a,
							Technology: a,
							Weight: "0",
							Size: a
						}],
						isAllLoaded: d,
						teaTab: c,
						pageIndex: 1,
						isInitLoad: e,
						swipeImgs: [{
							Banner: "http:\u002F\u002Fstatic.sxzisha.com\u002FUploadFiles\u002FPictureFiles\u002F茶叶banner_2020_01_03_16_20.png",
							ImgHyperlink: a
						}]
					}],
					error: a,
					state: {
						bottomMenuIndex: c,
						browserList: [],
						isFirstBrowser: e,
						is2Detail: d,
						isFromDetail: d
					},
					serverRendered: e
				}
			}(null, 2, 0, false, true));
		</script>
		<script src="/static/index/lib/jquery/jquery.js"></script>
		<script src="/static/index/js/rem.js"></script>
		<script src="/static/index/lib/vue/vue.min.js"></script>
		<script src="/static/index/js/action/font_1534256_qc3ia182za.js"></script>
		<script src="/static/index/lib/swiper/swiper.min4.js"></script>
		<script src="/static/index/js/tea.js"></script>
		<script src="/static/index/js/common.js"></script>

	</body>
</html>
