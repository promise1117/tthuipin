<?php /*a:1:{s:75:"E:\phpStudy\PHPTutorial\WWW\tp5.1\application\index\view\index\product.html";i:1583308540;}*/ ?>
<!doctype html>
<html>
<head>
    <title></title>
    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0,minimum-scale=1.0, maximum-scale=1.0">
    <meta data-n-head="ssr" name="keywords" data-hid="keywords" content="">
    <meta data-n-head="ssr" name="description" data-hid="description" content="">

    <link rel="stylesheet" type="text/css" href="./static/index/lib/swiper/swiper.min.css">
    <link rel="stylesheet" href="./static/index/css/style/cc9cbb9d0dd6b9ab414a.css">
    <link rel="stylesheet" href="./static/index/css/style/7c37c1f9cd04d16fbfdb.css">
    <link rel="stylesheet" href="./static/index/css/style/22905831efd53d205018.css">
    <link rel="stylesheet" type="text/css" href="./static/index/css/prudocts.css" />
</head>
<body>
<div data-server-rendered="true" id="__nuxt">
    <div id="__layout">
        <div style="max-width:750px;margin:0 auto;">
            <section data-v-1c281437>
                <div class="van-nav-bar van-hairline--bottom" style="z-index:1;" data-v-d09b833a data-v-d09b833a data-v-1c281437>
                    <div class="van-nav-bar__left" data-v-d09b833a data-v-d09b833a>
                        <i class="van-icon van-icon-arrow-left van-nav-bar__arrow" data-v-d09b833a data-v-d09b833a></i>
                        <span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>返回</span>
                    </div>
                    <div class="van-nav-bar__title van-ellipsis" data-v-d09b833a data-v-d09b833a>六方祥和-详情</div>
                    <div class="van-nav-bar__right" data-v-d09b833a data-v-d09b833a>
                        <span class="van-nav-bar__text" data-v-d09b833a data-v-d09b833a>首页</span>
                    </div>
                </div>


                <!-- Swiper轮播图 -->
                <div class="swiper-container">
                    <div class="swiper-wrapper"></div>
                    <div class="custom-indicator" data-v-1c281437>
                        1/4
                    </div>
                </div>

                <div class="goods_info" data-v-1c281437>
                    <h1 class="goods_name" data-v-1c281437>六方祥和</h1>
                    <ul data-v-1c281437>
                        <li data-v-1c281437>作者：陈江</li>
                        <li data-v-1c281437>壶型：六方</li>
                        <li data-v-1c281437>容量：360cc</li>
                        <li data-v-1c281437>泥料：段泥</li>
                        <li data-v-1c281437>主题：山水</li>
                        <!---->
                        <li style="color: red;" data-v-1c281437>No.37012</li>
                    </ul>
                    <!---->
                    <!---->
                    <!---->
                    <div class="query_container" data-v-1c281437><input type="tel" name id placeholder="请输入您的手机号" maxlength="11"
                                                                        value="" data-v-1c281437> <button class="van-button van-button--default van-button--normal" style="width:100px;height:30px;color:#fff;background:linear-gradient(to right, #736661, #362E2B);border:0;"
                                                                                                          data-v-1c281437 data-v-1c281437><span class="van-button__text" data-v-1c281437 data-v-1c281437>点击询价</span></button></div>
                </div>
                <div data-v-1c281437>
                    <div class="van-sticky">
                        <div data-v-1c281437="" class="van-tabs van-tabs--line">
                            <div class="van-tabs__wrap van-hairline--top-bottom">
                                <div role="tablist" class="van-tabs__nav van-tabs__nav--line" style="border-color: rgb(91, 72, 65); background: rgb(193, 194, 193);">
                                    <div role="tab" class="van-tab van-tab--active" style="" aria-selected="true"><span class="van-ellipsis">详情</span></div>
                                    <div role="tab" class="van-tab" style="color: rgb(91, 72, 65);"><span class="van-ellipsis">作者</span></div>
                                    <div role="tab" class="van-tab" style="color: rgb(91, 72, 65);"><span class="van-ellipsis">泥料</span></div>
                                    <div role="tab" class="van-tab" style="color: rgb(91, 72, 65);"><span class="van-ellipsis">付款方式</span></div>
                                    <div class="van-tabs__line" style="background-color: rgb(91, 72, 65); width: 47px; transform: translateX(47px) translateX(-50%); transition-duration: 0.3s;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="goods_description animated fadeIn" data-v-1c281437>
                    <p data-v-1c281437="">选用上等泥料紫泥手工制作，作品的精气神集合于一体，端庄若大家闺秀；圆润的的子与壶身一致，应和之下韵味十足；口盖子母线精确地将壶盖、壶口分割开来；大口盖，大气十足；色泽古朴，瑰丽至极，壶身装饰更为古雅，特别适宜于赏玩，收藏升值。</p>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaGoods/pictures_37012_1.jpg" alt data-v-1c281437>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaGoods/pictures_37012_2.jpg" alt data-v-1c281437>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaGoods/pictures_37012_3.jpg" alt data-v-1c281437>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaGoods/pictures_37012_4.jpg" al data-v-1c281437>

                </div>
                <div class="artist_description animated fadeIn" style="display:none;" data-v-1c281437>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaArtist/201710230947118230.jpg" alt data-v-1c281437>
                    <p data-v-1c281437>陈江 <a href="/Artist/detail/371" data-v-1c281437>进入详情</a></p>
                    <div class="rich_div" data-v-1c281437><strong>&nbsp; &nbsp; 陈江</strong>，男，生于1985年12月，2012年国家级助理工艺美术员。<br />
                        <div> &nbsp;&nbsp;&nbsp;&nbsp;1985年生于陶都宜兴，大学本科学历，师从方器名家高级工艺美术师谢永新。<br /> </div>
                        谢永新首徒，坚持不懈，至今已有十余年，形成了自己独特的艺术风格，作品在国内外专业展评中屡次获奖，备受藏家壶友的青睐和喜爱。<br /> &nbsp;&nbsp;&nbsp;&nbsp;多篇论文在江苏陶瓷发表<br />
                        <br /> &nbsp;&nbsp;&nbsp;&nbsp;八面玲珑壶 获全手工比赛2013-2015年优秀奖<br /> &nbsp;&nbsp;&nbsp;&nbsp;亚明四方壶 无锡博物馆永久收藏<br />
                        &nbsp;&nbsp;&nbsp;&nbsp;升方壶 无锡博物馆永久收藏<br /> &nbsp;&nbsp;&nbsp;&nbsp;菱花魁方壶 获上海国际博览会银奖<br />
                        &nbsp;&nbsp;&nbsp;&nbsp;汉方壶 获上海国际博览会银奖<br />
                    </div>
                </div>
                <div class="pug_description animated fadeIn" style="display:none;" data-v-1c281437>
                    <img src="http://static.sxzisha.com/UploadFiles/ZiShaGoods/段泥.jpg" alt data-v-1c281437>
                    <div class="rich_div" data-v-1c281437>简介：
                        段泥原矿称之“老团泥”，产于江苏省宜兴黄龙山，原矿外观近白色，夹深绿斑点；除可当泥胚製陶外，亦可磨筛成细颗粒，作为调砂效果之用；烧成后呈次鹅黄色，略含极少数红色斑点。另一缎泥之原矿为本山绿泥，产地亦为黄龙山，原矿呈绿灰色，是紫砂泥中夹层中的夹脂，烧成后呈米黄色调。泥料内所含颗粒较大结构疏松器身明显成双气孔结构，空气对流顺畅；日久使用，渐露锋芒，养成变化甚大为养壶之最佳器材。泡茶好喝，赞不绝口！早期泥料调配跟早期窑炉所升温度较低温，在一般缎泥产品会近期来所用窑炉为高温窑，所烧成之缎泥壶，可轻易提升至所须温度，而真正达到较高的结晶，绝不吐黑！
                        窑温：约1175~1180度。
                        收缩比：约12%。
                        矿产地：江苏宜兴赵庄山系朱泥矿~黄石黄之共生矿。
                        泥性：感甜嫩绵密，质坚而温润，呈近田黄色调，为江苏宜兴赵庄山系朱泥矿~黄石黄之共生矿，经挑拣练製而成，因含铁量只达6%左右，致陶之后呈“金田黄色”。
                        难度：
                        特点：许多玩家误认为缎泥会“吐黑”，其误解之起因，乃昔时窑炉均为低温窑，而缎泥系为高温泥(一般烧成温度约摄氏度1175~1180)，故每每窑烧不足，成品遇水后呈现还原为原矿色之现象(玩家称“吐黑”)；此为窑温不足所致，而非泥质之缺陷，希玩家勿因果倒置才是。
                        冲茗特性：缎泥适泡之茶较为宽广，一般而言，透气率均佳；茶汤顺和平适，操作冲茗技巧要求不高，甚适生手使用。
                        冲泡建议：普洱茶系列，铁观音及半发酵类茶，重发酵茶类（黑茶类），轻焙火乌龙茶，绿茶，龙井，红茶等_。</div>
                </div>

                <div class="more_goods" data-v-1c281437>
                    <div class="title" data-v-1c281437>
                        <h2 data-v-1c281437>相关作品</h2>
                    </div>
                </div>
                <ul class="clearfix" data-v-18cf6dfa="" data-v-6fc7e12e="">
                    <li data-v-18cf6dfa="">
                        <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                            <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                            </a>
                            <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                <div class="goods_header" data-v-217ef9e2="">
                                    <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                    <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                </div>
                                <div class="goods_info" data-v-217ef9e2="">
                                    <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                    <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li data-v-18cf6dfa="">
                        <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                            <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                            </a>
                            <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                <div class="goods_header" data-v-217ef9e2="">
                                    <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                    <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                </div>
                                <div class="goods_info" data-v-217ef9e2="">
                                    <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                    <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li data-v-18cf6dfa="">
                        <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                            <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                            </a>
                            <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                <div class="goods_header" data-v-217ef9e2="">
                                    <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                    <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                </div>
                                <div class="goods_info" data-v-217ef9e2="">
                                    <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                    <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li data-v-18cf6dfa="">
                        <div style="padding:0px;width:100%;" data-v-217ef9e2="" data-v-18cf6dfa="">
                            <a href="/shop/product/2816?type=1" class="goods_avatar_container" data-v-217ef9e2="">
                                <img data-v-217ef9e2="" alt="" class="goods_avatar" src="./static/index/img/thumbnail_41001.jpg">
                            </a>
                            <div style="margin-bottom: 10px;" data-v-217ef9e2="">
                                <div class="goods_header" data-v-217ef9e2="">
                                    <span class="goods_name" data-v-217ef9e2="">玉佩壶</span>
                                    <button class="btn_qry" data-v-217ef9e2="">询价</button>
                                </div>
                                <div class="goods_info" data-v-217ef9e2="">
                                    <span data-v-217ef9e2="">作者:鲍仲梅</span> <span data-v-217ef9e2="">编号:41001</span>
                                    <span data-v-217ef9e2="">泥料:红泥</span> <span data-v-217ef9e2="">容量:260cc</span>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </section>

            <section data-v-6e32b6c1="" class="consult_body" style="display: none;">
                <div class="van-overlay" style="z-index: 2001;"></div>
                <div data-v-6e32b6c1="" class="van-popup van-popup--round van-popup--bottom" style="width: 100%; z-index: 2002;">
                    <div data-v-6e32b6c1="" class="popover-bottom">
                        <div data-v-6e32b6c1="" class="header">
                            <img data-v-6e32b6c1="" src="http://static.sxzisha.com/static/l_logo.png" alt="">
                            <span data-v-6e32b6c1="" class="colse_consult">关闭</span></div>
                        <div data-v-6e32b6c1="" class="popover-container">
                            <div data-v-6e32b6c1="" class="phone_container" style="margin: 10px 0px;">
                                <span data-v-6e32b6c1="" style="font-size: 16px;">手机号码：</span>
                                <input data-v-6e32b6c1="" placeholder="  请输入您的手机号码" type="number" style="height: 24px; flex: 1 1 0%; max-width: 180px; border: 1px solid rgb(164, 164, 164);">
                            </div>
                            <span data-v-6e32b6c1="" style="color: rgb(219, 59, 46); font-size: 14px;">客服人员将在10分钟内回复</span>
                            <button data-v-6e32b6c1="" style="width: 100%; height: 30px; color: rgb(255, 255, 255); background-color: rgb(219, 59, 46); border: none; border-radius: 20px; margin-top: 20px;">立即咨询</button>
                            <div data-v-6e32b6c1="" class="bottomBtn">
										<span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-kefu">
												<use data-v-6e32b6c1="" xlink:href="#icon-kefu"></use>
											</svg>
											<div data-v-6e32b6c1="">在线客服</div>
										</span>
                                <span data-v-6e32b6c1="">
											<svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-imagewechat">
												<use data-v-6e32b6c1="" xlink:href="#icon-imagewechat"></use>
											</svg>
											<div data-v-6e32b6c1="">微信客服</div>
										</span>
                                <a data-v-6e32b6c1="" href="tel:4001168060">
                                    <svg data-v-6e32b6c1="" aria-hidden="true" class="icon icon-phone">
                                        <use data-v-6e32b6c1="" xlink:href="#icon-phone"></use>
                                    </svg>
                                    <div data-v-6e32b6c1="">拨打电话</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<script src="./static/index/lib/jquery/jquery.js"></script>
<script src="./static/index/js/rem.js"></script>
<script src="./static/index/js/action/font_1534256_qc3ia182za.js"></script>
<script src="./static/index/lib/swiper/swiper.min4.js" defer=""></script>
<script src="./static/index/js/prudocts.js" defer=""></script>
</body>
</html>
