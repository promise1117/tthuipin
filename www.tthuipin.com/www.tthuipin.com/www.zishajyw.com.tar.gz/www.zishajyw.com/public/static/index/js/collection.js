$(function() {
	let data_index = 1;

	const vm = new Vue({
		el: '#app',
		data: {
			goods: [],
			more:true
		},
		methods: {
			collpse() {
				if (this.more) {
					this.more = false;
					$('.artist_des').css({height:'724px'});
				}else{
					this.more = true;
					$('.artist_des').css({height:'50px'});
				}
			}
		},
		created() {
			$.ajax({
					url: "/collectionApi",
			 		type: 'post',
			 		data: {
			 			'type': 1,

			 		},
			 		dataType: 'json',
			 		success: function(data) {
			 			vm.goods = data.res[0].newest;
						console.log(vm.goods)
						$('.sort_container li').click(function() {
							const index = $(this).index();
							$(this).addClass('active').siblings().removeClass('active');
							switch (index) {
								case 0:
									vm.goods = data.res[0].newest;
									break;
								case 1:
									vm.goods = data.res[1].popularity;
									break;
								case 2:
									vm.goods = data.res[2].attached;
									break;
							}		
						});
					}
	})


		}
	})

	function checkWillLoad() {
		//直接取出最后一个盒子
		var lastBox = $('.list__item').last();
		//取出最后一个盒子高度的一半 + 头部偏离的位置
		var lastBoxDis = Math.floor($(lastBox).outerHeight() / 2) + $(lastBox).offset().top;
		//求出浏览器的高度
		var clientHeight = $(window).height();
		//求出页面偏离浏览器高度
		var scrollTopHeight = $(window).scrollTop();
		//比较返回
		return lastBoxDis <= clientHeight + scrollTopHeight;

	}

	let page = 1;
	let page_all = 2;

	/*$(window).on('scroll', function() {
		console.log(checkWillLoad())
		if (checkWillLoad()) {
				
			
				$('.van-toast--loading').show();
			setTimeout(function() {
				$('.van-toast--loading').hide();
				vm.goods = __NUXT__.data[0].goodsList;
			}, 2000);
			

			// page++;
			// if (page <= page_all) {
			// 	$.ajax({
			// 		url: "/get_category_list_api",
			// 		type: 'post',
			// 		data: {
			// 			'cat_id': 18,
			// 			'cat_name': "女生衣著",
			// 			'parent_id': 0,
			// 			'page': page,
			// 			'nav_id': 4
			// 		},
			// 		dataType: 'json',
			// 		success: function(data) {
			// 			page_all = data.page_all;
			// 			vm.goods.push.apply(vm.goods, data.goods);
			// 			console.log(vm.goods.length)
			// 		}
			// 	})
			// }


		}
	})
	*/
	
	
	// Tab切换
	$('.menu_container li').click(function() {
		const index = $(this).index();
		data_index = index;
		$(this).addClass('van-tab--active').siblings().removeClass('van-tab--active');
		$('.van-list').eq(index).show().siblings('.van-list').hide();
		console.log()
	});
	
	

})
