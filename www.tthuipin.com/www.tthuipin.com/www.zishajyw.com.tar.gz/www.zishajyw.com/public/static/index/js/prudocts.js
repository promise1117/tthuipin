$(function() {
	// 底部显示
	$('.bottom').show();
	$('.van-tabbar-item').removeClass('van-tabbar-item--active');
	
	 //Swiper轮播图
	$('#total').text($('.swiper-slide').length);
	
	const mySwiper = new Swiper('section .swiper-container', {
		autoplay: {
			delay: 6000,
		}, //自动滑动，5秒切换一次
		effect: 'slide', //滑动效果
		touchAngle: 30, //滑动的角度超过30度无效
		// 轮播图的方向，也可以是vertical方向
		direction: 'horizontal',
		//环形切换关闭
		loop: true,
		// 切换的速度
		speed: 800, //滑动或者自动换页时的速度
		// 这样，即使我们滑动之后， 定时器也不会被清除
		autoplayDisableOnInteraction: true,
		on: {
			slideChange: function() {
				// 获取当前活动下标
				var index = this.realIndex;
				$('#realIndex').text(index + 1);
			}
		}
	});

	// 点击询价
	function telphone() {
		let interval = null;
		const telphone = $("#xjTel").val();
		const regCode = /^1\d{10}$/;

		if (regCode.test(telphone) == false) {
			$('.van-toast--fail').show();
			setTimeout(function() {
				$('.van-toast--fail').hide();
			}, 2000);

			return false;
		} else {
			$('.van-toast--text').show();
			setTimeout(function() {
				$('.van-toast--text').hide();
			}, 2000);
			$('.van-button__text').html(60);
			$('.van-button').attr('disabled', true).css({background:'#A09C9A'})
			interval = setInterval(function() {
				var time = $('.van-button__text').html();
				time--;
				$('.van-button__text').html(time);
				if (time < 0) {
					clearInterval(interval);
					$('.van-button__text').html('点击询价');
					$('.van-button').removeAttr('disabled').css({background: 'linear-gradient(to right, #736661, #362E2B)'})
				}
			}, 1000)

			// var demand = [];
			// var demand = JSON.stringify(demand);
			// $.ajax({

			// 	type: 'post',

			// 	url: '/pc/pot/add.html',

			// 	data: {
			// 		'telphone': telphone,
			// 		'demand': demand
			// 	},

			// 	success: function(data) {

			// 		console.log(data);

			// 		layer.close(layer.index);

			// 		if (data.code == 0) {

			// 			layer.msg('提交成功', {
			// 				icon: 6,
			// 				time: 2000
			// 			})

			// 		} else {

			// 			layer.msg('提交失敗', {
			// 				icon: 5,
			// 				time: 2000
			// 			})

			// 		}

			// 	}
			// })

		}

	}

	
	$('.van-button').click(function() {
		telphone();
	})

	// Tab切换

	$('.van-tab').click(function() {
		const index = $(this).index();
		$(this).addClass('van-tab--active').siblings().removeClass('van-tab--active');
		switch (index) {
			case 0:
				$('.goods_description ').show();
				$('.artist_description,.pug_description,.pay_description').hide();
				break;
			case 1:
				$('.artist_description ').show();
				$('.goods_description,.pug_description,.pay_description').hide();
				break;
			case 2:
				$('.pug_description ').show();
				$('.goods_description,.artist_description,.pay_description').hide();
				break;
			case 3:
				$('.pay_description ').show();
				$('.goods_description,.artist_description,.pug_description').hide();
				break;	
		}
	});


	//图片整屏展示
	$('.goods_description img').click(function() {
		const index = $(this).attr('data-key');
		const src = $(this).attr('src');
		console.log($('.goods_description_img').length)
		$('#real').html(parseInt(index) + 1);
		$('#tot').html($('.goods_description_img').length);
		$('#pswp_img').attr('src',src);
		$('.pswp__scroll-wrap').show();
		$('body').addClass('ohm');

	})
	$('.pswp__button--close').click(function(e) {
		$('.pswp__scroll-wrap').hide();
		$('body').removeClass('ohm');

	})


	const top = $('.van-sticky').offset().top;

	$(window).on('scroll', function() {
		// 固定导航
		var scr = $(document).scrollTop();
		if (scr >= top) {
			$('.van-sticky').addClass('van-sticky--fixed');
		} else {
			$('.van-sticky').removeClass('van-sticky--fixed');
		};
	})




})
