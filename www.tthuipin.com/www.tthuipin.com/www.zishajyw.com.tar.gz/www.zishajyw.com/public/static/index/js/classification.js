$(function () {
	// 底部显示
			$('.bottom').show();
			$('.van-tabbar-item').eq(1).addClass('van-tabbar-item--active').siblings().removeClass('van-tabbar-item--active');
			$('.menu_left li').first().addClass('active');
			$('.menu_right').first().css('display','block');
	// 分类
	$('.menu_left li').click(function() {
		const index = $(this).index();
		$(this).addClass('active').siblings().removeClass('active');
		$('.menu_right').eq(index).show().siblings('.menu_right').hide();
	});
	

	
	
	
	
})