$(function() {
	const vm = new Vue({
		el: '#app',
		data: {
			goods: [],
		},
		methods: {
			// 询价
			inquiry(){
				$('.consult_body').show();
			},
			close_inquiry(){
				$('.consult_body').hide();
			}
			
		},
		created() {
			
		},
		mounted() {
			
		}
		
	})
	console.log(__NUXT__)

	function checkWillLoad() {
		//直接取出最后一个盒子
		var lastBox = $('.list__item').last();
		//取出最后一个盒子高度的一半 + 头部偏离的位置
		var lastBoxDis = Math.floor($(lastBox).outerHeight() / 2) + $(lastBox).offset().top;
		//求出浏览器的高度
		var clientHeight = $(window).height();
		//求出页面偏离浏览器高度
		var scrollTopHeight = $(window).scrollTop();
		//比较返回
		return lastBoxDis <= clientHeight + scrollTopHeight;

	}

	let page = 1;
	let page_all = 2;
	let data_index = 1;
	const top = $('.van-sticky').offset().top;

	$(window).on('scroll', function() {
		if (checkWillLoad()) {
			$('.van-toast--loading').show();
			setTimeout(function() {
				$('.van-toast--loading').hide();
				vm.goods = __NUXT__.data[0].goodsList;
			}, 1000);

			// page++;
			// if (page <= page_all) {
			// 	$.ajax({
			// 		url: "/get_category_list_api",
			// 		type: 'post',
			// 		data: {
			// 			'cat_id': 18,
			// 			'cat_name': "女生衣著",
			// 			'parent_id': 0,
			// 			'page': page,
			// 			'nav_id': 4
			// 		},
			// 		dataType: 'json',
			// 		success: function(data) {
			// 			page_all = data.page_all;
			// 			vm.goods.push.apply(vm.goods, data.goods);
			// 			console.log(vm.goods.length)
			// 		}
			// 	})
			// }

		}


		// 固定导航
		var scr = $(document).scrollTop();
		if (scr >= top) {
			$('.van-sticky').addClass('van-sticky--fixed');
		} else {
			$('.van-sticky').removeClass('van-sticky--fixed');
		};
	})

	// Tab切换
	$('.van-tab').click(function() {
		const index = $(this).attr('data-index');
		data_index = index;
		$(this).addClass('van-tab--active').siblings().removeClass('van-tab--active');
		console.log(data_index)
	});

	$('.sort_container li').click(function() {
		$(this).addClass('active').siblings().removeClass('active');
	});

	

})
